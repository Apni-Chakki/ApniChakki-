import{r as I,A as me,j as t,B as T,am as fe,W as he}from"./index-Dl2HPiLV.js";import{D as be,a as $e,b as ye,c as ve}from"./dialog-DtlH9UeT.js";import{P as Ne}from"./printer-B3X01POh.js";import{M as je}from"./message-circle-OWOEI3HH.js";const Y=({size:a=40})=>t.jsx("div",{className:"rounded-full bg-primary flex items-center justify-center shadow-sm flex-shrink-0",style:{width:a,height:a},children:t.jsx(he,{className:"text-primary-foreground",style:{width:a*.6,height:a*.6}})});function Re({order:a,open:A,onClose:z}){const[s,J]=I.useState("en"),[c,Q]=I.useState({name:"MUGHAL ATTA CHAKKI",address:"Main Bazaar, Lahore",phone:"+92 322 8483029",tagline:"Pure & Fresh Processing"});if(I.useEffect(()=>{A&&fetch(`${me}/get_store_settings.php`).then(e=>e.json()).then(e=>{e.success&&e.settings&&Q({name:e.settings.storeName||"MUGHAL ATTA CHAKKI",address:e.settings.address||"Main Bazaar, Lahore",phone:e.settings.phone||"+92 322 8483029",tagline:"Pure & Fresh Processing"})}).catch(e=>console.error("Error fetching store settings:",e))},[A]),!a)return null;const g=a.items.some(e=>e.isWeightPending),$=a.total-(a.advancePayment||0);let f=0,j=0;a.items.forEach(e=>{var n;if(!e.isWeightPending){const l=parseFloat(e.price_at_purchase)||parseFloat((n=e.service)==null?void 0:n.price)||0,o=parseFloat(e.original_price)||null,x=parseFloat(e.quantity)||0;o&&o>l?(f+=(o-l)*x,j+=o*x):j+=l*x}});const y=parseFloat(a.couponDiscount)||0,D=f+y>0,p=(e,n)=>{if(n==="en")return e;if(!e)return"";const l=e.trim(),o={"MUGHAL ATTA CHAKKI":"مغل آٹا چکی","Main Bazaar, Lahore":"مین بازار، لاہور","Pure & Fresh Processing":"خالص اور تازہ پروسیسنگ","Pure Grains, Fresh Quality":"خالص اناج، بہترین معیار","Wheat Flour":"گندم کا آٹا","Chakki Atta":"چکی کا آٹا","Special Atta":"خصوصی آٹا","Fine Atta":"فائن آٹا",Maida:"میدہ",Suji:"سوجی",Besan:"بیسن","Grinding Service":"پسائی کی سروس","Cleaning Service":"صفائی کی سروس",Wheat:"گندم",Gram:"چنا",Maize:"مکئی",Barley:"جَو",Millet:"باجرہ",Oats:"جئی",Rice:"چاول",Spices:"مصالحہ جات","Red Chili":"سرخ مرچ",Turmeric:"ہلدی",Coriander:"دھنیا"};if(o[l])return o[l];const x=l.toLowerCase();for(const r in o)if(r.toLowerCase()===x)return o[r];return e},M=(e,n="en")=>(n==="ur"?{pending:"زیر التواء",processing:"جاری ہے",ready:"تیار ہے پک اپ/ڈیلیوری کیلئے","out-for-delivery":"ڈیلیوری کے لیے روانہ",completed:"مکمل شدہ",cancelled:"منسوخ شدہ"}:{pending:"Pending",processing:"Processing",ready:"Ready for Pickup/Delivery","out-for-delivery":"Out for Delivery",completed:"Completed",cancelled:"Cancelled"})[e]||e,X=e=>({pending:"background:#fef9c3;color:#854d0e;border:1px solid #fde047;",processing:"background:#dbeafe;color:#1e40af;border:1px solid #93c5fd;",ready:"background:#dcfce7;color:#166534;border:1px solid #86efac;","out-for-delivery":"background:#f3e8ff;color:#6b21a8;border:1px solid #c4b5fd;",completed:"background:#d1fae5;color:#065f46;border:1px solid #6ee7b7;",cancelled:"background:#fee2e2;color:#991b1b;border:1px solid #fca5a5;"})[e]||"background:#f3f4f6;color:#374151;border:1px solid #d1d5db;",ee=e=>({pending:"bg-yellow-100 text-yellow-800 border-yellow-300",processing:"bg-blue-100 text-blue-800 border-blue-300",ready:"bg-green-100 text-green-800 border-green-300","out-for-delivery":"bg-purple-100 text-purple-800 border-purple-300",completed:"bg-emerald-100 text-emerald-800 border-emerald-300",cancelled:"bg-red-100 text-red-800 border-red-300"})[e]||"bg-gray-100 text-gray-700 border-gray-300",U=e=>s==="ur"?e==="delivery"?"ڈیلیوری":"پک اپ":e==="delivery"?"Delivery":"Pickup",E=e=>{const n=(e||"").toLowerCase();return s==="ur"?n==="jazzcash"?"جائز کیش":n==="easypaisa"?"ایزی پیسہ":n==="cash"?"نقد رقم":e||"نقد رقم":n==="jazzcash"?"JazzCash":n==="easypaisa"?"EasyPaisa":n==="cash"?"CASH":e||"CASH"},B=e=>s==="ur"?e==="paid"?"✓ ادا شدہ":e==="partial"?"جزوی ادائیگی":"✗ غیر ادا شدہ":e==="paid"?"✓ PAID":e==="partial"?"PARTIAL":"✗ UNPAID",k=(e,n,l)=>{if(l!=="ur")return e;const o=e.toLowerCase();return o==="kg"?"کلو":o==="unit"||o==="units"||o==="pcs"||o==="piece"||o==="pieces"?"عدد":e},R=e=>{var l;if(((l=e.customizations)==null?void 0:l.length)>0)return e.customizations.map(o=>p(o.option_name,s)).join(" + ");const n=[];return e.is_cleaning==1&&n.push(s==="ur"?"صفائی":"Cleaning"),e.is_grinding==1&&n.push(s==="ur"?"پسائی":"Grinding"),n.join(" + ")},te=()=>{const e=s==="ur",n=e?"rtl":"ltr",l=e?"'Noto Nastaliq Urdu', 'Jameel Noori Nastaliq', 'Urdu Typesetting', 'Tahoma', 'Arial', sans-serif":"'Courier New', monospace",o=`
      <div style="display:flex;flex-direction:column;align-items:center;text-align:center;padding:14px 0 10px;">
        <div style="width:50px;height:50px;border-radius:50%;background:#1a1a1a;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-bottom:8px;">
          <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M2 22 16 8"/><path d="M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M7.47 8.53 9 7l1.53 1.53a3.5 3.5 0 0 1 0 4.94L9 15l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M11.47 4.53 13 3l1.53 1.53a3.5 3.5 0 0 1 0 4.94L13 11l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z"/><path d="M11.47 17.47 13 19l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L5 19l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z"/><path d="M15.47 13.47 17 15l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L9 15l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z"/><path d="M19.47 9.47 21 11l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L13 11l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z"/>
          </svg>
        </div>
        <div>
          <div style="font-size:18px;font-weight:900;letter-spacing:${e?"0":"2px"};color:#1a1a1a;text-transform:uppercase;">${p(c.name,s)}</div>
          <div style="font-size:10px;color:#666;letter-spacing:${e?"0":"1px"};margin-top:2px;">${p(c.tagline,s)}</div>
          <div style="font-size:10px;color:#666;margin-top:1px;">📍 ${p(c.address,s)} &nbsp;|&nbsp; 📞 ${c.phone}</div>
        </div>
      </div>
    `,x=a.items.map(d=>{var W,q,H;const le=d.is_rental===1||d.is_rental==="1"||d.isRental,C=p(d.name||((W=d.service)==null?void 0:W.name),s);if(d.isWeightPending)return`
          <div style="border-bottom:1px dashed #ccc;padding:7px 0;text-align:${e?"right":"left"};">
            <div style="font-weight:600;font-size:12px;">${C}</div>
            <div style="color:#d97706;font-size:10px;font-weight:700;margin-top:2px;">⚠ ${e?"وزن کی تصدیق باقی ہے":"WEIGHT TO BE CONFIRMED"}</div>
          </div>`;const _=d.price_at_purchase||((q=d.service)==null?void 0:q.price)||0,O=d.original_price||null,F=O&&O>_;if(le){const Z=d.rental_price_per_day||_,K=d.rental_days||0,pe=d.security_deposit||0,V=d.runningPenalty||d.late_penalty_total||0,xe=Z*K,ue=d.rental_start_date?new Date(d.rental_start_date).toLocaleDateString():"",ge=d.rental_end_date?new Date(d.rental_end_date).toLocaleDateString():"";return`
          <div style="border-bottom:1px dashed #ccc;padding:7px 0;direction:${n};">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;">
              <div style="flex:1;padding-${e?"left":"right"}:10px;text-align:${e?"right":"left"};">
                <div style="font-weight:600;font-size:12px;">${C} (${e?"کرایہ":"Rental"})</div>
                <div style="font-size:10px;color:#555;margin-top:2px;">
                  🗓️ ${e?"مدت کرایہ:":"Rental Period:"} ${K} ${e?"دن":"days"} (${ue} - ${ge})
                </div>
                <div style="font-size:10px;color:#555;margin-top:2px;">
                  💰 ${e?"شرح کرایہ:":"Rate:"} Rs.${Number(Z).toLocaleString()}/${e?"دن":"day"}
                </div>
                <div style="font-size:10px;color:#555;margin-top:2px;">
                  🛡️ ${e?"سیکیورٹی ڈپازٹ:":"Security Deposit:"} Rs.${Number(pe).toLocaleString()}
                </div>
                ${V>0?`
                  <div style="font-size:10px;color:#b91c1c;font-weight:bold;margin-top:2px;">
                    ⚠️ ${e?"بقایا جرمانہ:":"Late Penalty:"} Rs.${Number(V).toLocaleString()}
                  </div>
                `:""}
              </div>
              <div style="text-align:${e?"left":"right"};">
                <div style="font-weight:700;white-space:nowrap;font-size:13px;">Rs.${Number(xe).toLocaleString()}</div>
              </div>
            </div>
          </div>
        `}const de=d.quantity*_,G=R(d),ce=k(d.unit||((H=d.service)==null?void 0:H.unit)||"unit",d.quantity,s);return`
        <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:1px dashed #ccc;padding:7px 0;direction:${n};">
          <div style="flex:1;padding-${e?"left":"right"}:10px;text-align:${e?"right":"left"};">
            <div style="font-weight:600;font-size:12px;">${C}</div>
            ${G?`
              <div style="color:#666;font-size:9px;font-style:italic;margin-top:2px;">
                (${G})
              </div>
            `:""}
            <div style="font-size:10px;margin-top:2px;">
              ${d.quantity} ${ce} ×
              ${F?`<span style="text-decoration:line-through;color:#999;">Rs.${Number(O).toLocaleString()}</span> <span style="color:#15803d;font-weight:700;">Rs.${Number(_).toLocaleString()}</span>`:`<span style="color:#555;">Rs.${Number(_).toLocaleString()}</span>`}
            </div>
          </div>
          <div style="text-align:${e?"left":"right"};">
            <div style="font-weight:700;white-space:nowrap;font-size:13px;">Rs.${Number(de).toLocaleString()}</div>
            ${F?`<div style="font-size:9px;color:#15803d;font-weight:700;">🏷 ${e?"ڈسکاؤنٹ":"Disc."}</div>`:""}
          </div>
        </div>`}).join(""),r=e?"سب ٹوٹل (اصل قیمت)":"SUBTOTAL (ORIGINAL PRICE)",u=e?"پروڈکٹ ڈسکاؤنٹ":"PRODUCT DISCOUNT",m=e?`کوپن ڈسکاؤنٹ (${a.couponCode||"PROMO"})`:`COUPON DISCOUNT (${a.couponCode||"PROMO"})`,i=e?"کل رقم (ڈسکاؤنٹ کے بعد)":"GRAND TOTAL (AFTER DISCOUNT)",v=e?"سب ٹوٹل":"SUBTOTAL";e?`${a.couponCode||"PROMO"}`:`${a.couponCode||"PROMO"}`;const h=e?"ایڈوانس ادائیگی":"ADVANCE PAID",b=e?"بقایا رقم":"REMAINING DUE",N=e?"ادائیگی کا طریقہ":"Payment Method",w=E(a.paymentMethod),L=e?"ادائیگی کی صورتحال":"Payment Status",S=B(a.paymentStatus),P=e?`⚠ رقم وصول کریں: Rs.${Number($).toLocaleString()}${g?" (+ تصدیق طلب)":""}`:`⚠ COLLECT PAYMENT: Rs.${Number($).toLocaleString()}${g?" (+ TBD)":""}`,ne=e?`پرنٹ کی تاریخ: ${new Date().toLocaleDateString("en-GB")} بجے ${new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"})}`:`Printed on: ${new Date().toLocaleDateString("en-GB")} at ${new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"})}`,re=e?"🙏 ہمارے کاروبار پر بھروسہ کرنے کا شکریہ!":"🙏 Thank you for your business!",ie=p(c.name,s),oe=p(c.tagline,s);return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8"/>
      <title>${e?"آرڈر کی تفصیلات":"Order Details"} — ${a.id}</title>
      <style>
        @page { size: A4; margin: 15mm 12mm; }
        * { box-sizing: border-box; margin: 0; padding: 0; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        body { font-family: ${l}; font-size: 12px; color: #111; background: #fff; direction: ${n}; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        .header { text-align: center; border-bottom: 2.5px dashed #333; padding-bottom: 10px; margin-bottom: 12px; }
        .doc-title { display:inline-block; border: 1.5px solid #555; padding: 3px 14px; border-radius: 4px; font-size: 11px; font-weight: 700; letter-spacing: ${e?"0":"2px"}; text-transform: uppercase; margin-top: 6px; }
        .section-title { font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: ${e?"0":"2px"}; color: #555; border-bottom: 1px dashed #aaa; padding-bottom: 4px; margin: 12px 0 7px; text-align: ${e?"right":"left"}; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 16px; background: #f9fafb; border: 1px solid #e5e7eb; padding: 10px 12px; border-radius: 6px; direction: ${n}; }
        .info-label { font-size: 9px; text-transform: uppercase; letter-spacing: ${e?"0":"1px"}; color: #777; font-weight: 700; margin-bottom: 2px; text-align: ${e?"right":"left"}; }
        .info-value { font-size: 11px; font-weight: 600; text-align: ${e?"right":"left"}; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 30px; font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: ${e?"0":"1px"}; }
        .row { display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 4px; direction: ${n}; }
        .muted { color: #666; }
        .bold { font-weight: 700; }
        .total-row { display: flex; justify-content: space-between; font-size: 13px; font-weight: 900; direction: ${n}; }
        .due-row { color: #b91c1c; border-top: 2px dashed #333; padding-top: 7px; margin-top: 7px; font-size: 15px; }
        .advance-row { color: #15803d; font-weight: 700; }
        .collect-box { background: #fef2f2; border: 2px solid #fca5a5; border-radius: 6px; padding: 10px; text-align: center; margin-top: 10px; }
        .collect-box p { font-size: 14px; font-weight: 900; text-transform: uppercase; color: #7f1d1d; }
        .footer { text-align: center; font-size: 10px; color: #777; border-top: 1.5px dashed #aaa; padding-top: 10px; margin-top: 14px; }
        .items-header { display:flex; justify-content:space-between; font-size:9px; font-weight:900; text-transform:uppercase; letter-spacing: ${e?"0":"1px"}; color:#888; padding:0 0 4px; direction: ${n}; }
        .cancel-box { grid-column:span 2; background:#fef2f2; border:1px solid #fca5a5; border-radius:4px; padding:8px; margin-top:4px; text-align: ${e?"right":"left"}; }
        .delivery-addr { font-size:11px; background:#eff6ff; border:1px solid #bfdbfe; padding:5px 8px; border-radius:4px; word-break:break-word; margin-top:4px; text-align: ${e?"right":"left"}; }
      </style>
    </head>
    <body>
      <div class="header">
        ${o}
        <div class="doc-title">${e?"آرڈر کی تفصیلات":"Order Details"}</div>
      </div>

      <!-- Order Info -->
      <div class="section-title">${e?"آرڈر کی معلومات":"Order Information"}</div>
      <div class="info-grid">
        <div>
          <div class="info-label">${e?"آرڈر آئی ڈی":"Order ID"}</div>
          <div class="info-value" style="font-size:10px;word-break:break-all;">${a.id}</div>
        </div>
        <div>
          <div class="info-label">${e?"آرڈر کی قسم":"Order Type"}</div>
          <div class="info-value" style="text-transform:uppercase;">${U(a.type)}</div>
        </div>
        <div>
          <div class="info-label">${e?"تاریخ اور وقت":"Date & Time"}</div>
          <div class="info-value">${new Date(a.createdAt).toLocaleDateString("en-GB")} ${new Date(a.createdAt).toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"})}</div>
        </div>
        <div>
          <div class="info-label">${e?"حیثیت":"Status"}</div>
          <span class="badge" style="${X(a.status)}">${M(a.status,s)}</span>
        </div>
        ${a.status==="cancelled"&&a.cancellationReason?`<div class="cancel-box"><div style="font-size:10px;color:#7f1d1d;font-weight:700;">${e?"منسوخی کی وجہ:":"Cancellation Reason:"}</div><div style="font-size:11px;color:#b91c1c;font-style:italic;margin-top:2px;">"${a.cancellationReason}"</div></div>`:""}
      </div>

      <!-- Customer Info -->
      <div class="section-title">${e?"کسٹمر کی معلومات":"Customer Information"}</div>
      <div class="row"><span class="muted">${e?"گاہک کا نام":"Customer Name"}</span><span class="bold">${a.customerName}</span></div>
      <div class="row"><span class="muted">${e?"فون نمبر":"Phone Number"}</span><span class="bold" style="font-family:monospace;">${a.phone}</span></div>
      ${a.deliveryAddress?`<div style="margin-top:4px;text-align:${e?"right":"left"};"><span style="font-size:10px;color:#666;">${e?"ڈیلیوری کا پتہ:":"Delivery Address:"}</span><div class="delivery-addr">${p(a.deliveryAddress,s)}</div></div>`:""}
      ${a.deliveryPersonnel?`<div class="row" style="margin-top:4px;"><span class="muted">${e?"ڈیلیوری کنندہ":"Delivery By"}</span><span class="bold">${a.deliveryPersonnel}</span></div>`:""}

      <!-- Items -->
      <div class="section-title">${e?"آرڈر کی اشیاء":"Order Items"}</div>
      <div class="items-header"><span>${e?"چیز / آئٹم":"Item"}</span><span>${e?"رقم":"Amount"}</span></div>
      ${x}

      <!-- Totals -->
      <div style="border-top:2.5px dashed #333;margin-top:10px;padding-top:10px;">
        ${D?`
          <div class="total-row">
            <span>${r}</span>
            <span>Rs.${Number(j).toLocaleString()}${g?e?" + تصدیق طلب":" + TBD":""}</span>
          </div>
          ${f>0?`
            <div class="row" style="color:#15803d;margin-top:5px;font-weight:700;">
              <span>${u}</span>
              <span>- Rs.${Number(f).toLocaleString()}</span>
            </div>
          `:""}
          ${y>0?`
            <div class="row" style="color:#15803d;margin-top:5px;font-weight:700;">
              <span>${m}</span>
              <span>- Rs.${Number(y).toLocaleString()}</span>
            </div>
          `:""}
          <div class="total-row" style="border-top:1px dashed #ccc;padding-top:7px;margin-top:7px;font-size:14px;color:#15803d;font-weight:900;">
            <span>${i}</span>
            <span>Rs.${Number(a.total).toLocaleString()}</span>
          </div>
        `:`
          <div class="total-row">
            <span>${v}</span>
            <span>Rs.${Number(a.total).toLocaleString()}${g?e?" + تصدیق طلب":" + TBD":""}</span>
          </div>
        `}
        ${a.advancePayment&&a.advancePayment>0?`
          <div class="row advance-row" style="margin-top:5px;">
            <span>${h}</span>
            <span>- Rs.${Number(a.advancePayment).toLocaleString()}</span>
          </div>
        `:""}
        ${$>0?`
          <div class="total-row due-row">
            <span>${b}</span>
            <span>Rs.${Number($).toLocaleString()}</span>
          </div>
        `:""}
      </div>

      <!-- Payment -->
      <div class="section-title">${e?"ادائیگی کی معلومات":"Payment Information"}</div>
      <div class="row"><span class="muted">${N}</span><span class="bold" style="text-transform:uppercase;">${w}</span></div>
      <div class="row"><span class="muted">${L}</span>
        <span style="font-weight:900;text-transform:uppercase;${a.paymentStatus==="paid"?"color:#15803d;":a.paymentStatus==="partial"?"color:#1d4ed8;":"color:#d97706;"}">
          ${S}
        </span>
      </div>
      ${a.paymentStatus==="paid"&&a.transactionId?`<div class="row"><span class="muted">${e?"ٹرانزیکشن آئی ڈی":"Transaction ID"}</span><span style="font-family:monospace;font-size:10px;">${a.transactionId}</span></div>`:""}
      ${a.paymentStatus!=="paid"&&$>0?`<div class="collect-box"><p>${P}</p></div>`:""}

      <div class="footer">
        <p>${ne}</p>
        <p style="margin-top:4px;">${re}</p>
        <p style="font-weight:700;margin-top:2px;">${ie} — ${oe}</p>
      </div>
    </body>
    </html>
  `},se=()=>{const e=s==="ur",n="%0A",l=a.total-(a.advancePayment||0),o=new Date(a.createdAt).toLocaleDateString("en-GB"),x=new Date(a.createdAt).toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"});let r="";if(e){r+=`*🧾 ${p(c.name,"ur")} - ڈیجیٹل بل*${n}`,r+=`─────────────────────────${n}`,r+=`📅 *تاریخ:* ${o}   ⏰ *وقت:* ${x}${n}`,r+=`🔢 *آرڈر نمبر:* ${a.id.slice(-6)}${n}`,r+=`👤 *گاہک:* ${a.customerName}${n}`,r+=`─────────────────────────${n}`,r+=`*🛒 آرڈر کی تفصیلات:*${n}`,a.items.forEach(i=>{var v,h,b,N;if(i.isWeightPending)r+=`▫️ *${p(i.name||((v=i.service)==null?void 0:v.name),"ur")}*${n}`,r+=`    _وزن کی تصدیق دکان پر کی جائے گی_${n}`;else{const w=i.price_at_purchase||((h=i.service)==null?void 0:h.price),L=k(i.unit||((b=i.service)==null?void 0:b.unit)||"unit",i.quantity,"ur"),S=p(i.name||((N=i.service)==null?void 0:N.name),"ur");r+=`▫️ *${S}*${n}`;const P=R(i);P&&(r+=`    _(${P})_${n}`),r+=`    ${i.quantity} ${L} x Rs.${w} = *Rs.${(i.quantity*w).toLocaleString()}*${n}`,(i.is_rental===1||i.is_rental==="1"||i.isRental)&&(r+=`    🗓️ _کرایہ: ${i.rental_days} دن (${i.rental_start_date} سے ${i.rental_end_date})_${n}`,r+=`    💰 _شرح: Rs. ${Number(i.rental_price_per_day).toLocaleString()}/دن | سیکیورٹی ڈپازٹ: Rs. ${Number(i.security_deposit).toLocaleString()}_${n}`)}}),r+=`─────────────────────────${n}`,g?r+=`*⚠️ فائنل بل وزن کے بعد تیار ہوگا*${n}`:(D&&(r+=`*سب ٹوٹل:* Rs.${j.toLocaleString()}${n}`,f>0&&(r+=`🏷️ *پروڈکٹ ڈسکاؤنٹ:* -Rs.${f.toLocaleString()}${n}`),y>0&&(r+=`🏷️ *کوپن ڈسکاؤنٹ (${a.couponCode||"PROMO"}):* -Rs.${y.toLocaleString()}${n}`)),r+=`*💰 کل رقم: Rs.${a.total.toLocaleString()}*${n}`);const m=parseFloat(a.advancePayment||a.amount_paid)||0;m>0&&(r+=`✅ *ایڈوانس ادائیگی: Rs.${m.toLocaleString()}*${n}`),l>0&&!g&&(r+=`❗ *بقایا رقم: Rs.${l.toLocaleString()}*${n}`),r+=`─────────────────────────${n}`,a.type==="delivery"&&(r+=`🚚 *ڈیلیوری کا پتہ:* ${a.deliveryAddress||"فراہم نہیں کیا گیا"}${n}`),r+=`📍 ${p(c.address,"ur")}${n}📞 ${c.phone}${n}`,r+=`🌾 _${p(c.tagline,"ur")}_`}else{r+=`*🧾 ${c.name.toUpperCase()} - DIGITAL INVOICE*${n}`,r+=`─────────────────────────${n}`,r+=`📅 *Date:* ${o}   ⏰ *Time:* ${x}${n}`,r+=`🔢 *Order No:* ${a.id.slice(-6)}${n}`,r+=`👤 *Customer:* ${a.customerName}${n}`,r+=`─────────────────────────${n}`,r+=`*🛒 ORDER SUMMARY:*${n}`,a.items.forEach(i=>{var v,h,b;if(i.isWeightPending)r+=`▫️ *${i.service.name}*${n}`,r+=`    _Weight to be confirmed at shop_${n}`;else{const N=i.price_at_purchase||((v=i.service)==null?void 0:v.price),w=i.unit||((h=i.service)==null?void 0:h.unit)||"unit",L=i.name||((b=i.service)==null?void 0:b.name);r+=`▫️ *${L}*${n}`;const S=R(i);S&&(r+=`    _(${S})_${n}`),r+=`    ${i.quantity} ${w} x Rs.${N} = *Rs.${(i.quantity*N).toLocaleString()}*${n}`,(i.is_rental===1||i.is_rental==="1"||i.isRental)&&(r+=`    🗓️ _Rental: ${i.rental_days} days (${i.rental_start_date} to ${i.rental_end_date})_${n}`,r+=`    💰 _Rate: Rs. ${Number(i.rental_price_per_day).toLocaleString()}/day | Deposit: Rs. ${Number(i.security_deposit).toLocaleString()}_${n}`)}}),r+=`─────────────────────────${n}`,g?r+=`*⚠️ FINAL TOTAL PENDING*${n}`:(D&&(r+=`*Subtotal:* Rs.${j.toLocaleString()}${n}`,f>0&&(r+=`🏷️ *Product Discount:* -Rs.${f.toLocaleString()}${n}`),y>0&&(r+=`🏷️ *Coupon Discount (${a.couponCode||"PROMO"}):* -Rs.${y.toLocaleString()}${n}`)),r+=`*💰 GRAND TOTAL: Rs.${a.total.toLocaleString()}*${n}`);const m=parseFloat(a.advancePayment||a.amount_paid)||0;m>0&&(r+=`✅ *Advance Paid: Rs.${m.toLocaleString()}*${n}`),l>0&&!g&&(r+=`❗ *BALANCE DUE: Rs.${l.toLocaleString()}*${n}`),r+=`─────────────────────────${n}`,a.type==="delivery"&&(r+=`🚚 *Delivery Address:* ${a.deliveryAddress||"Not provided"}${n}`),r+=`📍 ${c.address}${n}📞 ${c.phone}${n}`,r+=`🌾 _${c.tagline}_`}let u=a.phone.replace(/\D/g,"");u.startsWith("0")?u="92"+u.slice(1):u.startsWith("92")||(u="92"+u),window.open(`https://wa.me/${u}?text=${r}`,"_blank")},ae=()=>{const e=window.open("","_blank","width=700,height=800");e.document.open(),e.document.write(te()),e.document.close(),e.focus(),setTimeout(()=>{e.print(),e.close()},400)};return t.jsx(be,{open:A,onOpenChange:z,children:t.jsxs($e,{className:`max-w-lg p-0 gap-0 overflow-hidden ${s==="ur"?"text-right":"text-left"}`,hideCloseButton:!0,children:[t.jsx(ye,{className:"px-6 pt-4 pb-3 border-b border-border/50 bg-gradient-to-r from-amber-900/10 to-amber-800/5",children:t.jsx("div",{className:"flex items-center justify-between",dir:s==="ur"?"rtl":"ltr",children:t.jsxs("div",{className:"flex items-center gap-3",children:[t.jsx(Y,{size:40}),t.jsxs("div",{className:s==="ur"?"text-right":"text-left",children:[t.jsx(ve,{className:`text-sm font-black uppercase ${s==="ur"?"tracking-normal text-right":"tracking-wide"}`,children:p(c.name,s)}),t.jsx("p",{className:`text-[10px] text-muted-foreground ${s==="ur"?"text-right":""}`,children:s==="ur"?"آرڈر کی مکمل تفصیلات":"Full Order Details"})]})]})})}),t.jsx("div",{className:"overflow-y-auto",style:{maxHeight:"65vh"},children:t.jsxs("div",{className:`${s==="en"?"font-mono":""} text-sm px-6 py-5 space-y-4`,dir:s==="ur"?"rtl":"ltr",style:{direction:s==="ur"?"rtl":"ltr",fontFamily:s==="ur"?"'Noto Nastaliq Urdu', 'Jameel Noori Nastaliq', 'Urdu Typesetting', 'Tahoma', 'Arial', sans-serif":"monospace"},children:[t.jsxs("div",{className:"pb-4 border-b-2 border-dashed border-border",children:[t.jsxs("div",{className:"flex flex-col items-center text-center gap-2 mb-2.5",children:[t.jsx(Y,{size:50}),t.jsxs("div",{children:[t.jsx("h2",{className:`text-base font-black uppercase ${s==="ur"?"tracking-normal":"tracking-widest"}`,children:p(c.name,s)}),t.jsx("p",{className:`text-[9px] text-muted-foreground mt-0.5 uppercase ${s==="ur"?"tracking-normal":"tracking-wider"}`,children:p(c.tagline,s)}),t.jsxs("p",{className:"text-[9px] text-muted-foreground mt-0.5",children:["📍 ",p(c.address,s),"  |  📞 ",c.phone]})]})]}),t.jsx("div",{className:"text-center mt-2.5",children:t.jsx("div",{className:"inline-block border border-border rounded px-3 py-0.5",children:t.jsx("p",{className:`text-[9px] font-bold uppercase ${s==="ur"?"tracking-normal":"tracking-widest"}`,children:s==="ur"?"آرڈر کی تفصیلات":"Order Details"})})})]}),t.jsx("div",{className:"rounded-xl border border-border bg-muted/30 p-4",children:t.jsxs("div",{className:"grid grid-cols-2 gap-x-4 gap-y-3",children:[t.jsxs("div",{style:{textAlign:s==="ur"?"right":"left"},children:[t.jsx("p",{className:`text-[9px] uppercase text-muted-foreground font-bold ${s==="ur"?"tracking-normal":"tracking-wider"}`,children:s==="ur"?"آرڈر آئی ڈی":"Order ID"}),t.jsx("p",{className:"text-[10px] font-mono font-bold mt-0.5 break-all",children:a.id})]}),t.jsxs("div",{style:{textAlign:s==="ur"?"right":"left"},children:[t.jsx("p",{className:`text-[9px] uppercase text-muted-foreground font-bold ${s==="ur"?"tracking-normal":"tracking-wider"}`,children:s==="ur"?"قسم":"Type"}),t.jsx("p",{className:"text-[11px] font-bold uppercase mt-0.5",children:U(a.type)})]}),t.jsxs("div",{style:{textAlign:s==="ur"?"right":"left"},children:[t.jsx("p",{className:`text-[9px] uppercase text-muted-foreground font-bold ${s==="ur"?"tracking-normal":"tracking-wider"}`,children:s==="ur"?"تاریخ اور وقت":"Date & Time"}),t.jsxs("p",{className:"text-[10px] font-medium mt-0.5",children:[new Date(a.createdAt).toLocaleDateString("en-GB")," ",new Date(a.createdAt).toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"})]})]}),t.jsxs("div",{style:{textAlign:s==="ur"?"right":"left"},children:[t.jsx("p",{className:`text-[9px] uppercase text-muted-foreground font-bold ${s==="ur"?"tracking-normal":"tracking-wider"}`,children:s==="ur"?"حیثیت":"Status"}),t.jsx("span",{className:`inline-block mt-0.5 text-[9px] font-bold uppercase px-2 py-0.5 rounded-full border ${ee(a.status)}`,children:M(a.status,s)})]}),a.status==="cancelled"&&a.cancellationReason&&t.jsxs("div",{className:"col-span-2 bg-red-50 border border-red-300 rounded-lg p-2.5 mt-1",style:{textAlign:s==="ur"?"right":"left"},children:[t.jsx("p",{className:`text-[9px] uppercase text-red-500 font-bold mb-0.5 ${s==="ur"?"tracking-normal":"tracking-wider"}`,children:s==="ur"?"منسوخی کی وجہ":"Cancellation Reason"}),t.jsxs("p",{className:"text-[11px] text-red-700 italic",children:['"',a.cancellationReason,'"']})]})]})}),t.jsxs("div",{children:[t.jsxs("p",{className:`text-[9px] font-bold uppercase text-muted-foreground border-b border-dashed border-border pb-1.5 mb-2.5 ${s==="ur"?"tracking-normal":"tracking-widest"}`,children:["👤 ",s==="ur"?"کسٹمر کی معلومات":"Customer Information"]}),t.jsxs("div",{className:"space-y-1.5",children:[t.jsxs("div",{className:"flex justify-between text-[11px]",children:[t.jsx("span",{className:"text-muted-foreground",children:s==="ur"?"گاہک کا نام":"Customer Name"}),t.jsx("span",{className:"font-bold",children:a.customerName})]}),t.jsxs("div",{className:"flex justify-between text-[11px]",children:[t.jsx("span",{className:"text-muted-foreground",children:s==="ur"?"فون نمبر":"Phone Number"}),t.jsx("span",{className:"font-mono font-semibold",children:a.phone})]}),a.deliveryAddress&&t.jsxs("div",{style:{textAlign:s==="ur"?"right":"left"},children:[t.jsx("p",{className:"text-muted-foreground text-[9px] mb-1",children:s==="ur"?"ڈیلیوری کا پتہ":"Delivery Address"}),t.jsx("p",{className:"text-[11px] bg-blue-50 border border-blue-200 p-2 rounded-lg whitespace-normal break-words",children:p(a.deliveryAddress,s)})]}),a.deliveryPersonnel&&t.jsxs("div",{className:"flex justify-between text-[11px]",children:[t.jsx("span",{className:"text-muted-foreground",children:s==="ur"?"ڈیلیوری کنندہ":"Delivery By"}),t.jsx("span",{className:"font-semibold",children:a.deliveryPersonnel})]})]})]}),t.jsxs("div",{children:[t.jsxs("p",{className:`text-[9px] font-bold uppercase text-muted-foreground border-b-2 border-dashed border-border pb-1.5 mb-2.5 ${s==="ur"?"tracking-normal":"tracking-widest"}`,children:["🛒 ",s==="ur"?"آرڈر کی اشیاء":"Order Items"]}),t.jsxs("div",{className:`flex justify-between text-[9px] uppercase text-muted-foreground font-bold px-0.5 mb-1.5 ${s==="ur"?"tracking-normal":"tracking-wide"}`,children:[t.jsx("span",{children:s==="ur"?"آئٹم":"Item"}),t.jsx("span",{children:s==="ur"?"رقم":"Amount"})]}),t.jsx("div",{className:"space-y-2",children:a.items.map((e,n)=>{var o,x,r;const l=e.is_rental===1||e.is_rental==="1"||e.isRental;return t.jsxs("div",{className:"flex justify-between items-start border-b border-dashed border-border/50 pb-2 last:border-0",children:[t.jsxs("div",{className:`flex-1 ${s==="ur"?"pl-4":"pr-4"}`,style:{textAlign:s==="ur"?"right":"left"},children:[t.jsxs("p",{className:"text-[12px] font-semibold whitespace-normal break-words",children:[p(e.name||((o=e.service)==null?void 0:o.name),s)," ",l&&`(${s==="ur"?"کرایہ":"Rental"})`]}),l?t.jsxs("div",{className:"text-[10px] text-muted-foreground mt-1 space-y-0.5",style:{textAlign:s==="ur"?"right":"left"},children:[t.jsxs("p",{children:["🗓️ ",s==="ur"?"مدت کرایہ:":"Rental Period:"," ",e.rental_days," ",s==="ur"?"دن":"days"," (",e.rental_start_date," ",s==="ur"?"سے":"to"," ",e.rental_end_date,")"]}),t.jsxs("p",{children:["💰 ",s==="ur"?"شرح کرایہ:":"Rate:"," Rs. ",Number(e.rental_price_per_day||e.price_at_purchase).toLocaleString(),"/",s==="ur"?"دن":"day"]}),t.jsxs("p",{children:["🛡️ ",s==="ur"?"سیکیورٹی ڈپازٹ:":"Security Deposit:"," Rs. ",Number(e.security_deposit).toLocaleString()]}),parseFloat(e.runningPenalty||e.late_penalty_total||0)>0&&t.jsxs("p",{className:"text-red-600 font-bold",children:["⚠️ ",s==="ur"?"بقایا جرمانہ:":"Late Penalty:"," Rs. ",Number(e.runningPenalty||e.late_penalty_total).toLocaleString()]})]}):t.jsxs(t.Fragment,{children:[(((x=e.customizations)==null?void 0:x.length)>0||e.is_cleaning==1||e.is_grinding==1)&&t.jsxs("p",{className:"text-[9px] text-muted-foreground italic mt-0.5",children:["(",R(e),")"]}),e.isWeightPending?t.jsxs("p",{className:"text-[10px] text-orange-600 font-bold mt-0.5",children:["⚠ ",s==="ur"?"وزن کی تصدیق باقی ہے":"WEIGHT TO BE CONFIRMED"]}):(()=>{var h,b;const u=e.price_at_purchase||((h=e.service)==null?void 0:h.price)||0,m=e.original_price||null,i=m&&m>u,v=k(e.unit||((b=e.service)==null?void 0:b.unit)||"unit",e.quantity,s);return t.jsxs("p",{className:"text-[10px] mt-0.5 flex items-center gap-1 flex-wrap",children:[t.jsxs("span",{className:"text-muted-foreground",children:[e.quantity," ",v," ×"]}),i?t.jsxs(t.Fragment,{children:[t.jsxs("span",{className:"line-through text-muted-foreground",children:["Rs.",Number(m).toLocaleString()]}),t.jsxs("span",{className:"text-green-600 font-bold",children:["Rs.",Number(u).toLocaleString()]}),t.jsxs("span",{className:"text-green-600 text-[9px] font-bold bg-green-50 border border-green-200 px-1 rounded",children:["🏷 ",s==="ur"?"ڈسکاؤنٹ":"DISC"]})]}):t.jsxs("span",{className:"text-muted-foreground",children:["Rs.",Number(u).toLocaleString()]})]})})()]})]}),!e.isWeightPending&&t.jsxs("p",{className:"text-[12px] font-bold whitespace-nowrap",children:["Rs.",l?(Number(e.rental_days)*Number(e.rental_price_per_day||e.price_at_purchase)).toLocaleString():(e.quantity*(e.price_at_purchase||((r=e.service)==null?void 0:r.price)||0)).toLocaleString()]})]},n)})})]}),t.jsxs("div",{className:"rounded-xl border border-border bg-muted/20 p-4 space-y-2",children:[D?t.jsxs(t.Fragment,{children:[t.jsxs("div",{className:"flex justify-between text-[13px] font-bold text-muted-foreground",children:[t.jsx("span",{children:s==="ur"?"سب ٹوٹل (اصل قیمت)":"SUBTOTAL (ORIGINAL PRICE)"}),t.jsxs("span",{className:"whitespace-nowrap",children:["Rs.",Number(j).toLocaleString(),g&&t.jsx("span",{className:"text-orange-500",children:s==="ur"?" + تصدیق طلب":" + TBD"})]})]}),f>0&&t.jsxs("div",{className:"flex justify-between text-[12px] text-green-600 font-bold",children:[t.jsx("span",{children:s==="ur"?"پروڈکٹ ڈسکاؤنٹ":"PRODUCT DISCOUNT"}),t.jsxs("span",{className:"whitespace-nowrap",children:["- Rs.",Number(f).toLocaleString()]})]}),y>0&&t.jsxs("div",{className:"flex justify-between text-[12px] text-green-600 font-bold",children:[t.jsx("span",{children:s==="ur"?`کوپن ڈسکاؤنٹ (${a.couponCode||"PROMO"})`:`COUPON DISCOUNT (${a.couponCode||"PROMO"})`}),t.jsxs("span",{className:"whitespace-nowrap",children:["- Rs.",Number(y).toLocaleString()]})]}),t.jsxs("div",{className:"flex justify-between text-[14px] font-black pt-2 border-t border-dashed border-border text-green-700",children:[t.jsx("span",{children:s==="ur"?"کل رقم (ڈسکاؤنٹ کے بعد)":"GRAND TOTAL (AFTER DISCOUNT)"}),t.jsxs("span",{className:"whitespace-nowrap",children:["Rs.",Number(a.total).toLocaleString()]})]})]}):t.jsxs("div",{className:"flex justify-between text-[13px] font-bold",children:[t.jsx("span",{children:s==="ur"?"سب ٹوٹل":"SUBTOTAL"}),t.jsxs("span",{className:"whitespace-nowrap",children:["Rs.",Number(a.total).toLocaleString(),g&&t.jsx("span",{className:"text-orange-500",children:s==="ur"?" + تصدیق طلب":" + TBD"})]})]}),parseFloat(a.advancePayment)>0&&t.jsxs("div",{className:"flex justify-between text-[12px]",children:[t.jsx("span",{className:"text-muted-foreground",children:s==="ur"?"ایڈوانس ادائیگی":"ADVANCE PAID"}),t.jsxs("span",{className:"text-green-600 font-bold whitespace-nowrap",children:["- Rs.",Number(a.advancePayment).toLocaleString()]})]}),$>0&&t.jsxs("div",{className:"flex justify-between text-[15px] font-black pt-2 border-t-2 border-dashed border-border",children:[t.jsx("span",{className:"text-red-600",children:s==="ur"?"بقایا رقم":"REMAINING DUE"}),t.jsxs("span",{className:"text-red-600 whitespace-nowrap",children:["Rs.",Number($).toLocaleString()]})]})]}),t.jsxs("div",{children:[t.jsxs("p",{className:`text-[9px] font-bold uppercase text-muted-foreground border-b border-dashed border-border pb-1.5 mb-2.5 ${s==="ur"?"tracking-normal":"tracking-widest"}`,children:["💳 ",s==="ur"?"ادائیگی کی معلومات":"Payment Information"]}),t.jsxs("div",{className:"space-y-1.5",children:[t.jsxs("div",{className:"flex justify-between text-[11px]",children:[t.jsx("span",{className:"text-muted-foreground",children:s==="ur"?"ادائیگی کا طریقہ":"Payment Method"}),t.jsx("span",{className:"uppercase font-bold",children:E(a.paymentMethod)})]}),t.jsxs("div",{className:"flex justify-between text-[11px]",children:[t.jsx("span",{className:"text-muted-foreground",children:s==="ur"?"ادائیگی کی صورتحال":"Payment Status"}),t.jsx("span",{className:`uppercase font-black ${a.paymentStatus==="paid"?"text-green-600":a.paymentStatus==="partial"?"text-blue-600":"text-orange-500"}`,children:B(a.paymentStatus)})]}),a.paymentStatus==="paid"&&a.transactionId&&t.jsxs("div",{className:"flex justify-between text-[11px]",children:[t.jsx("span",{className:"text-muted-foreground",children:s==="ur"?"ٹرانزیکشن آئی ڈی":"Transaction ID"}),t.jsx("span",{className:"font-mono text-[10px]",children:a.transactionId})]})]}),a.paymentStatus!=="paid"&&$>0&&t.jsx("div",{className:"mt-3 bg-red-50 border-2 border-red-300 rounded-xl p-3 text-center",children:t.jsxs("p",{className:"text-red-900 font-black text-[13px] uppercase tracking-wide",children:["⚠ ",s==="ur"?"رقم وصول کریں:":"COLLECT PAYMENT:"," Rs.",Number($).toLocaleString(),g&&(s==="ur"?" (+ تصدیق طلب)":" (+ TBD)")]})})]}),t.jsxs("div",{className:"border-t border-dashed border-border pt-3 text-center space-y-0.5",children:[t.jsxs("p",{className:"text-[9px] text-muted-foreground",children:[s==="ur"?"پرنٹ کی تاریخ:":"Printed:"," ",new Date().toLocaleDateString("en-GB")," ",s==="ur"?"بجے":"at"," ",new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"})]}),t.jsx("p",{className:"text-[9px] text-muted-foreground",children:s==="ur"?"🙏 ہمارے کاروبار پر بھروسہ کرنے کا شکریہ!":"🙏 Thank you for your business!"}),t.jsxs("p",{className:"text-[9px] text-muted-foreground font-bold",children:[p(c.name,s)," — ",p(c.tagline,s)]})]})]})}),t.jsxs("div",{className:"flex gap-2.5 px-6 py-4 border-t border-border/50 bg-background",dir:s==="ur"?"rtl":"ltr",children:[t.jsxs(T,{onClick:ae,className:"flex-1 bg-primary hover:bg-primary/90 text-sm h-9",children:[t.jsx(Ne,{className:`h-4 w-4 ${s==="ur"?"ml-2":"mr-2"}`}),s==="ur"?"پرنٹ کریں":"Print Details"]}),t.jsxs(T,{onClick:se,className:"flex-1 bg-green-600 hover:bg-green-700 text-white text-sm h-9",children:[t.jsx(je,{className:`h-4 w-4 ${s==="ur"?"ml-2":"mr-2"}`}),s==="ur"?"واٹس ایپ":"WhatsApp"]}),t.jsxs(T,{variant:"outline",size:"sm",onClick:()=>J(s==="en"?"ur":"en"),className:"flex items-center gap-2 px-3 min-w-[80px] justify-center border-input bg-transparent hover:bg-accent hover:text-accent-foreground",children:[t.jsx(fe,{className:"h-4 w-4"}),t.jsx("span",{className:"font-semibold text-xs",children:s==="en"?"اردو":"English"})]}),t.jsx(T,{onClick:z,variant:"outline",className:"flex-1 text-sm h-9",children:s==="ur"?"بند کریں":"Close"})]})]})})}export{Re as P};
