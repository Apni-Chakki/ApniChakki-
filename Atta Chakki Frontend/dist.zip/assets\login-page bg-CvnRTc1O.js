const g="/assets/login-page%20bg-C5Ol3M44.jpg";export{g as l};
