import{r as n,A as $,j as e,B as g,X as te,b as se,t as m,L as z,E as I,z as re,O as ae,P as ne}from"./index-Dl2HPiLV.js";import{C as y}from"./card-19iuz211.js";import{I as R}from"./input-DMrihvvM.js";import{L as F}from"./label-2oYQ02MS.js";import{T as le}from"./textarea-qR0JBmou.js";import{T as oe,a as ie,b as E,c as h,d as ce,e as u}from"./table-DnoGW0eb.js";import{D as O,a as _,b as B,c as q,e as de,d as xe}from"./dialog-DtlH9UeT.js";import{P as A}from"./printer-B3X01POh.js";import{S as pe,a as me,b as he,c as ue,d as H}from"./select-I2uZv719.js";import{T as ge}from"./triangle-alert-CHtrTd0s.js";import{S as fe}from"./search-9fzkpYtN.js";import{M as je}from"./minus-DNEHuYsZ.js";import"./index--W9ygoIB.js";import"./index-Bf-I292j.js";import"./index-CVHX3zK7.js";import"./index-BjpeAUXd.js";import"./chevron-down-DYgj85pX.js";import"./check-ByT7pZYG.js";import"./chevron-up-Df25x0BV.js";function ye({items:w,open:o,onClose:N}){const[f,S]=n.useState({name:"MUGHAL ATTA CHAKKI",address:"",phone:"",tagline:""});n.useEffect(()=>{o&&fetch(`${$}/get_store_settings.php`).then(s=>s.json()).then(s=>{s.success&&s.settings&&S({name:s.settings.storeName||"MUGHAL ATTA CHAKKI",address:s.settings.address||"",phone:s.settings.phone||"",tagline:s.settings.tagline||""})}).catch(s=>console.error("Failed to load store settings",s))},[o]);const i=[...w].sort((s,x)=>{const r=s.currentStock<=s.minStockLevel,a=x.currentStock<=x.minStockLevel;return r&&!a?-1:!r&&a?1:s.productName.localeCompare(x.productName)}),v=i.filter(s=>s.currentStock<=s.minStockLevel).length,k=()=>{const s=window.open("","_blank","width=800,height=900");if(!s){alert("Please allow popups to print the report.");return}s.document.open(),s.document.write(j()),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},500)},j=()=>{const s=new Date().toLocaleString(),x=`
      <div style="display:flex;align-items:center;justify-content:center;gap:14px;padding:5px 0 10px;">
        <svg width="56" height="56" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="32" cy="32" r="32" fill="#78350f"/>
          <ellipse cx="32" cy="38" rx="16" ry="8" fill="#fef3c7" opacity="0.9"/>
          <ellipse cx="32" cy="36" rx="12" ry="6" fill="#f59e0b" opacity="0.8"/>
          <line x1="32" y1="44" x2="32" y2="18" stroke="#fef3c7" stroke-width="2" stroke-linecap="round"/>
          <ellipse cx="27" cy="28" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(-30 27 28)"/>
          <ellipse cx="26" cy="23" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(-25 26 23)"/>
          <ellipse cx="37" cy="28" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(30 37 28)"/>
          <ellipse cx="38" cy="23" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(25 38 23)"/>
          <ellipse cx="32" cy="20" rx="3" ry="4" fill="#fef3c7"/>
        </svg>
        <div>
          <div style="font-size:18px;font-weight:900;letter-spacing:2px;color:#1a1a1a;text-transform:uppercase;">${f.name}</div>
          <div style="font-size:10px;color:#666;letter-spacing:1px;margin-top:2px;">${f.tagline}</div>
          <div style="font-size:10px;color:#666;margin-top:1px;">📍 ${f.address} &nbsp;|&nbsp; 📞 ${f.phone}</div>
        </div>
      </div>
    `,r=i.length===0?'<tr><td colspan="6" style="text-align:center;padding:12px;color:#666;">No items found in inventory.</td></tr>':i.map((a,c)=>{const p=a.currentStock<=a.minStockLevel,d=p?Math.max(0,a.minStockLevel-a.currentStock+20):0;return`
          <tr style="${p?"background-color:#fff0f0;":""}">
            <td style="padding:8px 10px;border-bottom:1px solid #eee;text-align:center;">${c+1}</td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;font-weight:600;">${a.productName}</td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;text-align:right;${p?"color:#b91c1c;font-weight:bold;":""}">${a.currentStock} ${a.unit}</td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;text-align:right;">${a.minStockLevel} ${a.unit}</td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;text-align:center;">
              <span style="${p?"background:#fee2e2;color:#991b1b;border:1px solid #fca5a5;":"background:#dcfce7;color:#166534;border:1px solid #86efac;"} padding:2px 6px; border-radius:4px; font-size:11px; font-weight:bold;">
                ${p?"LOW STOCK":"OK"}
              </span>
            </td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;text-align:right;font-weight:bold;">
              ${p?`<span style="color:#b91c1c;">+${d} ${a.unit}</span>`:'<span style="color:#9ca3af;font-weight:normal;">-</span>'}
            </td>
          </tr>
        `}).join("");return`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Inventory Status Report</title>
        <style>
          body { font-family: 'Inter', system-ui, -apple-system, sans-serif; padding: 20px; color: #111827; line-height: 1.5; }
          .header-section { text-align: center; border-bottom: 2px solid #78350f; padding-bottom: 15px; margin-bottom: 24px; }
          .title-area { margin-top: 15px; display:flex; justify-content: space-between; align-items:flex-end; }
          .report-title { font-size: 24px; font-weight: 800; color: #111827; margin: 0; text-transform: uppercase; }
          .report-meta { font-size: 13px; color: #4b5563; text-align:right; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 30px; font-size: 13px; }
          th { background: #f9fafb; padding: 10px; text-align: left; font-weight: 700; color: #374151; border-bottom: 2px solid #e5e7eb; }
          .summary-container { display: flex; gap: 40px; margin-top: 30px; page-break-inside: avoid; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; background: #fffaf0; }
          .summary-col { flex: 1; }
          .signatures { display: flex; justify-content: space-between; margin-top: 60px; padding-top: 20px; border-top: 1px solid #d1d5db; page-break-inside: avoid; }
          .sig-line { width: 200px; text-align: center; }
          .sig-line div { border-top: 1px solid #374151; padding-top: 5px; font-size: 13px; font-weight: 500; }
          @media print {
            body { padding: 0; }
            .no-print { display: none !important; }
            @page { margin: 15mm; }
          }
        </style>
      </head>
      <body>
        <div class="header-section">
          ${x}
          <div class="title-area">
            <div style="text-align:left;">
              <h1 class="report-title">Inventory Restock</h1>
              <p style="margin:4px 0 0;font-weight:500;color:#6b7280;font-size:14px;">Status Report</p>
            </div>
            <div class="report-meta">
              <div>Total Items: ${w.length}</div>
              <div>Generated: ${s}</div>
            </div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width:5%;text-align:center;">#</th>
              <th style="width:30%">Product Name</th>
              <th style="width:15%;text-align:right;">Current Stock</th>
              <th style="width:15%;text-align:right;">Min. Level</th>
              <th style="width:15%;text-align:center;">Status</th>
              <th style="width:20%;text-align:right;">Action / Required</th>
            </tr>
          </thead>
          <tbody>
            ${r}
          </tbody>
        </table>

        <div class="summary-container" style="justify-content:center; align-items:center; background:#fef2f2; border:1px solid #fecaca;">
          <div style="text-align:center;">
            <div style="font-size:14px;font-weight:600;color:#991b1b;margin-bottom:4px;text-transform:uppercase;letter-spacing:1px;">Critical Attention Required</div>
            <div style="font-size:24px;font-weight:800;color:#dc2626;">${v} Items Low on Stock</div>
          </div>
        </div>

        <div class="signatures">
          <div class="sig-line">
            <div style="margin-top:50px;">Manager Signature</div>
          </div>
          <div class="sig-line">
            <div style="margin-top:50px;">Date & Time</div>
          </div>
        </div>
      </body>
      </html>
    `};return e.jsx(O,{open:o,onOpenChange:N,children:e.jsxs(_,{className:"max-w-[400px] text-center",children:[e.jsxs(B,{children:[e.jsx("div",{className:"mx-auto bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4",children:e.jsx(A,{className:"h-8 w-8 text-primary"})}),e.jsx(q,{className:"text-xl",children:"Print Restock List"})]}),e.jsxs("div",{className:"py-4",children:[e.jsx("p",{className:"text-muted-foreground mb-4",children:"You are about to generate an inventory restock report highlighting low stock items."}),e.jsxs("div",{className:"bg-muted/50 p-4 rounded-lg flex justify-between items-center text-sm border border-border",children:[e.jsx("span",{children:"Total Items Tracked:"}),e.jsx("span",{className:"font-bold",children:w.length})]}),e.jsxs("div",{className:"bg-red-50 p-4 rounded-lg flex justify-between items-center text-sm border border-red-100 mt-2",children:[e.jsx("span",{className:"text-red-700",children:"Low Stock Items:"}),e.jsx("span",{className:"font-bold text-red-700 text-lg",children:v})]})]}),e.jsxs(de,{className:"flex-col sm:flex-row gap-2 w-full mt-2",children:[e.jsxs(g,{variant:"outline",onClick:N,className:"w-full sm:flex-1",children:[e.jsx(te,{className:"h-4 w-4 mr-2"})," Cancel"]}),e.jsxs(g,{onClick:k,className:"w-full sm:flex-1 bg-primary",children:[e.jsx(A,{className:"h-4 w-4 mr-2"})," Print Document"]})]})]})})}function Ee(){const{user:w}=se(),[o,N]=n.useState([]),[f,S]=n.useState(!0),[i,v]=n.useState(!1),[k,j]=n.useState(!1),[s,x]=n.useState(!1),[r,a]=n.useState(null),[c,p]=n.useState("add"),[d,L]=n.useState(""),[K,C]=n.useState(""),[D,W]=n.useState(""),[T,G]=n.useState("all");n.useEffect(()=>{P()},[]);const P=async()=>{try{S(!0);const l=await(await fetch(`${$}/get_inventory.php`)).json();l.success?N(l.inventory):m.error(l.message||"Failed to load inventory")}catch(t){console.error("Network Error:",t),m.error("Network error: Could not load inventory")}finally{S(!1)}},Q=async()=>{if(!r||!d){m.error("Please enter quantity");return}const t=parseFloat(d);if(isNaN(t)||t<=0){m.error("Please enter a valid positive number");return}v(!0);try{const b=await(await fetch(`${$}/manual_stock_update.php`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({product_id:r.id,quantity:t,type:c})})).json();b.success?(m.success("Inventory updated successfully!"),j(!1),L(""),C(""),a(null),P()):m.error(b.message||"Failed to update inventory")}catch(l){console.error("Network Error:",l),m.error("Network error while updating stock")}finally{v(!1)}},U=(t,l)=>{a(t),p(l),j(!0)},V=t=>t.currentStock<=t.minStockLevel?{label:"Low Stock",color:"bg-red-500 text-white"}:t.maxStockLevel&&t.currentStock>=t.maxStockLevel?{label:"Full Stock",color:"bg-blue-500 text-white"}:t.currentStock<=t.minStockLevel*1.5?{label:"Medium Stock",color:"bg-yellow-500 text-white"}:{label:"Good Stock",color:"bg-green-500 text-white"},Y=()=>{x(!0)},J=Array.from(new Set(o.map(t=>t.category).filter(Boolean))).sort(),M=o.filter(t=>{const l=(t.productName||t.name||"").toLowerCase(),b=D.toLowerCase(),Z=l.includes(b)||(t.category||"").toLowerCase().includes(b),ee=T==="all"||t.category===T;return Z&&ee}),X=o.filter(t=>t.currentStock<=t.minStockLevel).length;return f&&o.length===0?e.jsxs("div",{className:"flex flex-col items-center justify-center h-64 space-y-4",children:[e.jsx(z,{className:"h-8 w-8 animate-spin text-primary"}),e.jsx("p",{className:"text-muted-foreground",children:"Loading Inventory Data..."})]}):e.jsxs("div",{children:[e.jsxs("div",{className:"mb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4",children:[e.jsxs("div",{children:[e.jsx("h1",{className:"text-foreground mb-2",children:"Inventory Management"}),e.jsx("p",{className:"text-muted-foreground",children:"Track and manage stock levels for your products"})]}),e.jsxs(g,{variant:"outline",onClick:Y,children:[e.jsx(A,{className:"h-4 w-4 mr-2"}),"Print Restock List"]})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4 mb-6",children:[e.jsx(y,{className:"p-4",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"Total Products"}),e.jsx("p",{className:"text-2xl mt-1",children:o.length})]}),e.jsx("div",{className:"h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center",children:e.jsx(I,{className:"h-6 w-6 text-primary"})})]})}),e.jsx(y,{className:"p-4",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"Low Stock"}),e.jsx("p",{className:"text-2xl mt-1",children:X})]}),e.jsx("div",{className:"h-12 w-12 rounded-full bg-red-500/10 flex items-center justify-center",children:e.jsx(ge,{className:"h-6 w-6 text-red-600"})})]})}),e.jsx(y,{className:"p-4",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"Well Stocked"}),e.jsx("p",{className:"text-2xl mt-1",children:o.filter(t=>t.currentStock>t.minStockLevel).length})]}),e.jsx("div",{className:"h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center",children:e.jsx(re,{className:"h-6 w-6 text-green-600"})})]})})]}),e.jsx(y,{className:"p-4 mb-6",children:e.jsxs("div",{className:"flex flex-col sm:flex-row gap-4 items-center",children:[e.jsxs("div",{className:"relative flex-1 w-full",children:[e.jsx(fe,{className:"absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"}),e.jsx(R,{placeholder:"Search product...",value:D,onChange:t=>W(t.target.value),className:"pl-10"})]}),e.jsx("div",{className:"w-full sm:w-[200px]",children:e.jsxs(pe,{value:T,onValueChange:G,children:[e.jsx(me,{children:e.jsx(he,{placeholder:"Category"})}),e.jsxs(ue,{children:[e.jsx(H,{value:"all",children:"All Categories"}),J.map(t=>e.jsx(H,{value:t,children:t},t))]})]})})]})}),M.length===0?e.jsxs(y,{className:"p-12 text-center",children:[e.jsx(I,{className:"h-16 w-16 text-muted-foreground mx-auto mb-4"}),e.jsx("p",{className:"text-muted-foreground mb-2",children:"No matching products found."})]}):e.jsx(y,{className:"overflow-hidden",children:e.jsxs(oe,{children:[e.jsx(ie,{children:e.jsxs(E,{className:"bg-muted/50",children:[e.jsx(h,{children:"Product Name"}),e.jsx(h,{children:"Current Stock"}),e.jsx(h,{children:"Min Level"}),e.jsx(h,{children:"Max Level"}),e.jsx(h,{children:"Status"}),e.jsx(h,{children:"Last Updated"}),e.jsx(h,{children:"Actions"})]})}),e.jsx(ce,{children:M.map(t=>{const l=V(t);return e.jsxs(E,{children:[e.jsx(u,{children:e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(I,{className:"h-4 w-4 text-muted-foreground"}),e.jsx("span",{children:t.productName})]})}),e.jsx(u,{children:e.jsxs("span",{className:"text-lg",children:[t.currentStock," ",t.unit]})}),e.jsx(u,{children:e.jsxs("span",{className:"text-muted-foreground",children:[t.minStockLevel," ",t.unit]})}),e.jsx(u,{children:e.jsxs("span",{className:"text-muted-foreground",children:[t.maxStockLevel||"-"," ",t.maxStockLevel?t.unit:""]})}),e.jsx(u,{children:e.jsx(ae,{className:l.color,children:l.label})}),e.jsx(u,{children:e.jsx("span",{className:"text-sm text-muted-foreground",children:new Date(t.lastUpdated).toLocaleDateString()})}),e.jsx(u,{children:e.jsxs("div",{className:"flex gap-2",children:[e.jsxs(g,{size:"sm",variant:"outline",onClick:()=>U(t,"add"),className:"text-green-600 hover:bg-green-50 flex items-center",children:[e.jsx(ne,{className:"h-4 w-4 mr-1",strokeWidth:3}),"Add"]}),e.jsxs(g,{size:"sm",variant:"outline",onClick:()=>U(t,"remove"),className:"text-red-600 hover:bg-red-50 flex items-center",children:[e.jsx(je,{className:"h-4 w-4 mr-1",strokeWidth:3}),"Remove"]})]})})]},t.id)})})]})}),e.jsx(O,{open:k,onOpenChange:j,children:e.jsxs(_,{children:[e.jsxs(B,{children:[e.jsx(q,{children:c==="add"?"Add Stock":c==="remove"?"Remove Stock":"Adjust Stock"}),e.jsxs(xe,{children:["Update inventory for ",r==null?void 0:r.productName]})]}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"Current Stock"}),e.jsxs("p",{className:"text-2xl",children:[r==null?void 0:r.currentStock," ",r==null?void 0:r.unit]})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsxs(F,{children:[c==="adjust"?"New Stock Level":"Quantity"," (",r==null?void 0:r.unit,")"]}),e.jsx(R,{type:"number",min:"0",step:"0.01",value:d,onChange:t=>L(t.target.value),placeholder:c==="adjust"?"Enter new stock level":"Enter quantity",disabled:i})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx(F,{children:"Notes (Optional)"}),e.jsx(le,{value:K,onChange:t=>C(t.target.value),placeholder:"Add any notes about this update...",rows:3,disabled:i})]}),d&&r&&e.jsxs("div",{className:"p-4 bg-muted rounded-lg",children:[e.jsx("p",{className:"text-sm text-muted-foreground mb-1",children:"New Stock Level"}),e.jsxs("p",{className:"text-xl",children:[c==="add"?r.currentStock+(parseFloat(d)||0):c==="remove"?Math.max(0,r.currentStock-(parseFloat(d)||0)):parseFloat(d)||0," ",r.unit]})]}),e.jsxs("div",{className:"flex gap-2",children:[e.jsxs(g,{onClick:Q,className:"flex-1",disabled:i,children:[i?e.jsx(z,{className:"mr-2 h-4 w-4 animate-spin"}):null,i?"Updating...":"Update Inventory"]}),e.jsx(g,{variant:"outline",disabled:i,onClick:()=>{j(!1),L(""),C("")},children:"Cancel"})]})]})]})}),e.jsx(ye,{items:o,open:s,onClose:()=>x(!1)})]})}export{Ee as InventoryManagement};
