import{r as P,A as U,j as e,X as M,B as $}from"./index-Dl2HPiLV.js";import{D as W,a as I,b as O,c as H}from"./dialog-DtlH9UeT.js";import{P as G}from"./printer-B3X01POh.js";const k=s=>new Date(s).toLocaleDateString("en-GB")+" "+new Date(s).toLocaleTimeString("en-GB",{hour:"2-digit",minute:"2-digit"}),z=s=>s.filter(l=>l.paymentStatus==="paid").length,T=s=>s.filter(l=>l.paymentStatus==="pending").length,S=s=>s.filter(l=>l.type==="delivery").length,D=s=>s.filter(l=>l.type==="pickup").length,L=s=>s.filter(l=>l.paymentStatus==="partial").length,R=({size:s=48})=>e.jsxs("svg",{width:s,height:s,viewBox:"0 0 64 64",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("circle",{cx:"32",cy:"32",r:"32",fill:"#78350f"}),e.jsx("ellipse",{cx:"32",cy:"38",rx:"16",ry:"8",fill:"#fef3c7",opacity:"0.9"}),e.jsx("ellipse",{cx:"32",cy:"36",rx:"12",ry:"6",fill:"#f59e0b",opacity:"0.8"}),e.jsx("line",{x1:"32",y1:"44",x2:"32",y2:"18",stroke:"#fef3c7",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("ellipse",{cx:"27",cy:"28",rx:"4",ry:"2.5",fill:"#fef3c7",transform:"rotate(-30 27 28)"}),e.jsx("ellipse",{cx:"26",cy:"23",rx:"4",ry:"2.5",fill:"#fef3c7",transform:"rotate(-25 26 23)"}),e.jsx("ellipse",{cx:"37",cy:"28",rx:"4",ry:"2.5",fill:"#fef3c7",transform:"rotate(30 37 28)"}),e.jsx("ellipse",{cx:"38",cy:"23",rx:"4",ry:"2.5",fill:"#fef3c7",transform:"rotate(25 38 23)"}),e.jsx("ellipse",{cx:"32",cy:"20",rx:"3",ry:"4",fill:"#fef3c7"})]});function Y({orders:s,title:l,open:f,onClose:h}){const[c,C]=P.useState({name:"GRISTMILL'S",address:"",phone:"",tagline:""});P.useEffect(()=>{f&&fetch(`${U}/get_store_settings.php`).then(t=>t.json()).then(t=>{t.success&&t.settings&&C({name:t.settings.storeName||"GRISTMILL'S",address:t.settings.address||"",phone:t.settings.phone||"",tagline:t.settings.tagline||""})}).catch(t=>console.error("Failed to load store settings",t))},[f]);const A=()=>{const t=window.open("","_blank","width=800,height=900");t.document.open(),t.document.write(B()),t.document.close(),t.focus(),setTimeout(()=>{t.print(),t.close()},400)},y=s.filter(t=>!t.items.some(d=>d.isWeightPending||d.is_weight_pending)).reduce((t,d)=>t+d.total,0),b=s.filter(t=>t.items.some(d=>d.isWeightPending||d.is_weight_pending)),B=()=>{const t=`
      <div style="display:flex;align-items:center;justify-content:center;gap:14px;padding:14px 0 10px;">
        <svg width="56" height="56" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="32" cy="32" r="32" fill="#78350f"/>
          <ellipse cx="32" cy="38" rx="16" ry="8" fill="#fef3c7" opacity="0.9"/>
          <ellipse cx="32" cy="36" rx="12" ry="6" fill="#f59e0b" opacity="0.8"/>
          <line x1="32" y1="44" x2="32" y2="18" stroke="#fef3c7" stroke-width="2" stroke-linecap="round"/>
          <ellipse cx="27" cy="28" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(-30 27 28)"/>
          <ellipse cx="26" cy="23" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(-25 26 23)"/>
          <ellipse cx="37" cy="28" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(30 37 28)"/>
          <ellipse cx="38" cy="23" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(25 38 23)"/>
          <ellipse cx="32" cy="20" rx="3" ry="4" fill="#fef3c7"/>
        </svg>
        <div>
          <div style="font-size:18px;font-weight:900;letter-spacing:2px;color:#1a1a1a;text-transform:uppercase;">${c.name}</div>
          <div style="font-size:10px;color:#666;letter-spacing:1px;margin-top:2px;">${c.tagline}</div>
          <div style="font-size:10px;color:#666;margin-top:1px;">📍 ${c.address} &nbsp;|&nbsp; 📞 ${c.phone}</div>
        </div>
      </div>
    `,d=s.map((i,a)=>{const r=i.total-(i.advancePayment||0),v=(i.items||[]).map(n=>{var j,N,w;const m=n.name||((j=n.service)==null?void 0:j.name)||"Unknown Item",g=n.unit||((N=n.service)==null?void 0:N.unit)||"",x=n.price||((w=n.service)==null?void 0:w.price)||0,u=n.isWeightPending||n.is_weight_pending||!1,_=u?'<span style="font-weight:bold;">(Pending Wt.)</span>':`${n.quantity} ${g}`,E=!u&&x>0?`Rs.${n.quantity*x}`:"";return`<div style="display:flex;justify-content:space-between;font-size:11px;margin-top:4px;">
            <span>${m} × ${_}</span>
            <span style="font-weight:600;">${E}</span>
        </div>`}).join("");let p="";i.status==="cancelled"&&(p=`<div style="background:#fef2f2;border:1px solid #fca5a5;padding:6px;border-radius:4px;margin-top:8px;">
            <div style="font-size:10px;font-weight:bold;color:#7f1d1d;">CANCELLED</div>
            ${i.cancellationReason?`<div style="font-size:10px;font-style:italic;color:#991b1b;">Reason: ${i.cancellationReason}</div>`:""}
            ${i.cancelledBy?`<div style="font-size:10px;color:#991b1b;">By: ${i.cancelledBy}</div>`:""}
        </div>`);let o="";return i.paymentStatus!=="paid"&&i.paymentMethod==="cash"&&i.status!=="cancelled"&&r>0&&(o=`<div style="text-align:center;font-weight:800;font-size:12px;margin-top:8px;padding-top:6px;border-top:1.5px dashed #000;">
           COLLECT: Rs.${r} ${i.items.some(n=>n.isWeightPending||n.is_weight_pending)?"(+ TBD)":""}
        </div>`),`
        <div class="order-card">
          <div class="card-header">
            <div>
              <div style="font-size:13px;font-weight:800;">#${a+1} – ${i.customerName}</div>
              <div style="font-size:10px;color:#555;">ID: ${i.id}</div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:11px;font-weight:600;">SUBTOTAL: Rs.${i.total} ${i.items.some(n=>n.isWeightPending||n.is_weight_pending)?"(+TBD)":""}</div>
              ${i.advancePayment>0?`<div style="font-size:10px;color:#166534;">ADVANCE: Rs.${i.advancePayment}</div>`:""}
              ${r>0?`<div style="font-size:12px;font-weight:800;color:#b91c1c;">DUE: Rs.${r}</div>`:""}
              <div style="font-size:10px;font-weight:800;margin-top:2px;">STATUS: ${i.paymentStatus?i.paymentStatus.toUpperCase():"PENDING"}</div>
            </div>
          </div>

          <div class="grid-2" style="font-size:10px;margin-bottom:8px;">
            <div>Phone: <b>${i.phone}</b></div>
            <div>Type: <b style="text-transform:uppercase;">${i.type}</b></div>
            <div>Payment: <b style="text-transform:uppercase;">${i.paymentMethod}</b></div>
            <div>Status: <b style="text-transform:uppercase;">${i.status?i.status.replace(/-/g," "):"N/A"}</b></div>
          </div>
          
          ${i.deliveryAddress?`<div style="font-size:10px;margin-bottom:8px;"><b>Address:</b> ${i.deliveryAddress}</div>`:""}
          
          <div style="border-top:1px dashed #666;padding-top:6px;">
            <div style="font-size:10px;font-weight:700;margin-bottom:4px;">Items:</div>
            ${v}
          </div>
          
          ${p}
          ${o}
        </div>
      `}).join("");return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8"/>
      <title>${l}</title>
      <style>
        @page { size: A4 landscape; margin: 10mm; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Courier New', monospace; font-size: 12px; color: #111; background: #fff; padding: 10px; }
        .header { text-align: center; border-bottom: 2.5px dashed #333; padding-bottom: 10px; margin-bottom: 15px; }
        .doc-title { font-size: 14px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; margin-top: 10px; }
        
        .summary-box { border: 2px dashed #000; padding: 12px; border-radius: 6px; background: #fdfdfd; margin-bottom: 20px; }
        .summary-title { text-align: center; font-weight: 900; font-size: 14px; margin-bottom: 10px; }
        .grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; text-align: center; }
        .grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 4px; }
        
        .orders-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
        .order-card { border: 1.5px solid #000; padding: 12px; border-radius: 4px; page-break-inside: avoid; }
        .card-header { display: flex; justify-content: space-between; border-bottom: 1px dashed #666; padding-bottom: 8px; margin-bottom: 8px; }
        
        .footer { text-align: center; font-size: 10px; color: #555; border-top: 1.5px dashed #000; padding-top: 10px; margin-top: 20px; }
      </style>
    </head>
    <body>
      <div class="header">
        ${t}
        <div class="doc-title">${l}</div>
        <div style="font-size:10px;margin-top:4px;">Printed on: ${k(new Date)}</div>
      </div>

      <div class="summary-box">
        <div class="summary-title">SUMMARY</div>
        <div class="grid-3">
          <div><div style="font-size:10px;color:#555;">Total Orders</div><div style="font-size:16px;font-weight:900;">${s.length}</div></div>
          <div><div style="font-size:10px;color:#555;">Confirmed Revenue</div><div style="font-size:16px;font-weight:900;">Rs. ${y}</div></div>
          <div><div style="font-size:10px;color:#555;">Pending Weight</div><div style="font-size:16px;font-weight:900;">${b.length}</div></div>
          <div><div style="font-size:10px;color:#555;">Paid/Partial/Unpaid</div><div style="font-size:14px;font-weight:700;">${z(s)} / ${L(s)} / ${T(s)}</div></div>
          <div><div style="font-size:10px;color:#555;">Delivery/Pickup</div><div style="font-size:14px;font-weight:700;">${S(s)} / ${D(s)}</div></div>
        </div>
      </div>

      <div class="orders-grid">
        ${d}
      </div>

      <div class="footer">End of ${l}</div>
    </body>
    </html>
    `};return e.jsx(W,{open:f,onOpenChange:h,children:e.jsxs(I,{className:"max-w-4xl w-[95vw] p-0 gap-0 overflow-hidden shadow-2xl rounded-2xl border-2 border-stone-200",hideCloseButton:!0,children:[e.jsx(O,{className:"px-6 pt-4 pb-3 border-b border-border/50 bg-gradient-to-r from-amber-900/10 to-amber-800/5",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx(R,{size:40}),e.jsxs("div",{children:[e.jsx(H,{className:"text-sm font-black tracking-wide uppercase",children:c.name}),e.jsxs("p",{className:"text-[10px] text-muted-foreground",children:["Preview: ",l]})]})]}),e.jsx("button",{onClick:h,className:"rounded-full p-1.5 hover:bg-muted transition-colors",children:e.jsx(M,{className:"h-4 w-4 text-muted-foreground"})})]})}),e.jsx("div",{className:"overflow-y-auto bg-stone-50",style:{maxHeight:"70vh"},children:e.jsx("div",{className:"p-4 sm:p-6 lg:p-8",children:e.jsxs("div",{id:"printable-list",className:"font-mono text-sm space-y-6 bg-white text-black p-6 sm:p-8 rounded-xl shadow-md border border-stone-300 max-w-3xl mx-auto",children:[e.jsxs("div",{className:"text-center border-b-2 border-dashed border-black pb-4",children:[e.jsx("div",{className:"flex justify-center mb-2",children:e.jsx(R,{size:56})}),e.jsx("h2",{className:"text-2xl font-bold mb-1 uppercase tracking-widest",children:c.name}),c.tagline&&e.jsx("p",{className:"text-[10px] text-gray-600 uppercase tracking-wide mt-1",children:c.tagline}),e.jsxs("p",{className:"text-[10px] text-gray-600 mt-1",children:["📍 ",c.address,"  |  📞 ",c.phone]}),e.jsx("h3",{className:"text-lg mt-4 font-semibold",children:l}),e.jsxs("p",{className:"text-xs mt-2",children:["Printed on: ",k(new Date)]})]}),e.jsxs("div",{className:"border-2 border-dashed border-black p-5 bg-gray-50/50 rounded",children:[e.jsx("h4",{className:"text-center font-bold mb-3 text-base",children:"SUMMARY"}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4 text-sm",children:[e.jsxs("div",{className:"text-center",children:[e.jsx("p",{className:"text-gray-600",children:"Total Orders"}),e.jsx("p",{className:"text-xl font-bold",children:s.length})]}),e.jsxs("div",{className:"text-center",children:[e.jsx("p",{className:"text-gray-600",children:"Confirmed Revenue"}),e.jsxs("p",{className:"text-xl font-bold",children:["Rs. ",y]})]}),e.jsxs("div",{className:"text-center",children:[e.jsx("p",{className:"text-gray-600",children:"Pending Weight"}),e.jsxs("p",{className:"text-xl font-bold",children:[b.length," Orders"]})]}),e.jsxs("div",{className:"text-center",children:[e.jsx("p",{className:"text-gray-600",children:"Paid / Partial / Unpaid"}),e.jsxs("p",{className:"text-xl font-semibold",children:[z(s)," / ",L(s)," / ",T(s)]})]}),e.jsxs("div",{className:"text-center",children:[e.jsx("p",{className:"text-gray-600",children:"Delivery / Pickup"}),e.jsxs("p",{className:"text-xl font-semibold",children:[S(s)," / ",D(s)]})]})]})]}),e.jsx("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-4",children:s.map((t,d)=>{const i=t.total-(t.advancePayment||0);return e.jsxs("div",{className:"border-2 border-solid border-black p-4 rounded-lg bg-white",children:[e.jsxs("div",{className:"flex justify-between mb-3 border-b border-dashed border-gray-400 pb-3",children:[e.jsxs("div",{children:[e.jsxs("p",{className:"text-base font-extrabold uppercase",children:["#",d+1," – ",t.customerName]}),e.jsxs("p",{className:"text-xs text-gray-500",children:["ID: ",t.id]})]}),e.jsxs("div",{className:"text-right",children:[e.jsxs("p",{className:"text-sm font-bold",children:["SUBTOTAL: Rs. ",t.total,t.items.some(a=>a.isWeightPending||a.is_weight_pending)&&" (+TBD)"]}),t.advancePayment&&t.advancePayment>0&&e.jsxs("p",{className:"text-xs text-green-700 font-bold",children:["ADVANCE: Rs. ",t.advancePayment]}),i>0&&e.jsxs("p",{className:"text-base font-black text-red-700",children:["DUE: Rs. ",i]}),e.jsxs("p",{className:`text-xs font-black uppercase mt-1 ${t.paymentStatus==="paid"?"text-green-700":t.paymentStatus==="partial"?"text-blue-700":"text-orange-700"}`,children:["STATUS: ",t.paymentStatus||"PENDING"]})]})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2 text-xs mb-3 font-medium text-gray-800",children:[e.jsxs("div",{children:["Phone: ",e.jsx("span",{className:"font-bold text-black",children:t.phone})]}),e.jsxs("div",{children:["Type: ",e.jsx("span",{className:"uppercase font-bold text-black",children:t.type})]}),e.jsxs("div",{children:["Payment: ",e.jsx("span",{className:"uppercase font-bold text-black",children:t.paymentMethod})]}),e.jsxs("div",{children:["Status: ",e.jsx("span",{className:"uppercase font-bold text-black",children:t.status?t.status.replace(/-/g," "):"N/A"})]})]}),t.deliveryAddress&&e.jsxs("div",{className:"mb-3 text-xs bg-blue-50/50 p-2 rounded border border-blue-100",children:[e.jsx("span",{className:"font-bold text-gray-700",children:"Address: "}),e.jsx("span",{className:"break-words font-medium",children:t.deliveryAddress})]}),e.jsxs("div",{className:"border-t border-dashed border-gray-400 pt-3",children:[e.jsx("p",{className:"text-xs font-bold text-gray-500 mb-2 uppercase tracking-widest",children:"Items"}),e.jsx("div",{className:"space-y-1.5 text-xs",children:t.items&&t.items.map((a,r)=>{var m,g,x;const v=a.name||((m=a.service)==null?void 0:m.name)||"Unknown Item",p=a.unit||((g=a.service)==null?void 0:g.unit)||"",o=a.price||((x=a.service)==null?void 0:x.price)||0,n=a.isWeightPending||a.is_weight_pending||!1;return e.jsxs("div",{className:"flex justify-between font-medium",children:[e.jsxs("span",{className:"break-words w-[70%]",children:[v," × ",n?e.jsx("span",{className:"font-bold text-orange-600",children:"(Pending Wt.)"}):e.jsxs("span",{className:"font-bold",children:[a.quantity," ",p]})]}),!n&&o>0&&e.jsxs("span",{className:"font-bold whitespace-nowrap",children:["Rs. ",a.quantity*o]})]},r)})})]}),t.status==="cancelled"&&e.jsxs("div",{className:"mt-3 pt-2 border-t border-dashed border-gray-400",children:[e.jsx("p",{className:"text-xs font-black text-red-600",children:"CANCELLED"}),t.cancellationReason&&e.jsxs("p",{className:"text-xs italic text-red-500",children:["Reason: ",t.cancellationReason]}),t.cancelledBy&&e.jsxs("p",{className:"text-xs text-red-500",children:["By: ",t.cancelledBy]})]}),t.paymentStatus!=="paid"&&t.paymentMethod==="cash"&&t.status!=="cancelled"&&i>0&&e.jsxs("div",{className:"mt-3 py-2 border-y-2 border-dashed border-black text-center font-black text-sm bg-red-50 text-red-900",children:["COLLECT: Rs. ",i,t.items.some(a=>a.isWeightPending||a.is_weight_pending)&&" (+ TBD)"]})]},t.id)})}),e.jsx("div",{className:"text-center text-xs text-gray-500 pt-6 border-t-2 border-dashed border-black",children:e.jsxs("p",{className:"font-medium",children:["End of ",l]})})]})})}),e.jsxs("div",{className:"flex gap-2.5 px-6 py-4 border-t border-border/50 bg-background",children:[e.jsxs($,{onClick:A,className:"flex-1 bg-primary hover:bg-primary/90 text-sm h-9",children:[e.jsx(G,{className:"h-4 w-4 mr-2"}),"Print Full List"]}),e.jsx($,{onClick:h,variant:"outline",className:"flex-1 text-sm h-9",children:"Close"})]})]})})}export{Y as P};
