import{r as n,A as L,j as e,B as m,X as he,b as fe,L as J,P as ue,ah as ge,C as R,n as W,t as l}from"./index-Dl2HPiLV.js";import{C as M}from"./card-19iuz211.js";import{I as Q}from"./input-DMrihvvM.js";import{L as D}from"./label-2oYQ02MS.js";import{S as X,a as q,b as Z,c as ee,d as T}from"./select-I2uZv719.js";import{T as ye,a as je,b as z,c as j,d as be,e as h}from"./table-DnoGW0eb.js";import{T as ve}from"./textarea-qR0JBmou.js";import{e as H,s as _,P as te,a as se,b as re,C as ae}from"./calendar-CncP-96Q.js";import{D as we,a as Ne,b as Se,c as Ce,e as De}from"./dialog-DtlH9UeT.js";import{P as B}from"./printer-B3X01POh.js";import{T as Te}from"./trending-down-BW_23UFK.js";import{f}from"./format-SmSpYad1.js";import{T as Le}from"./trash-2-BzHmUh6O.js";import"./index-CVHX3zK7.js";import"./index-Bf-I292j.js";import"./index-BjpeAUXd.js";import"./chevron-down-DYgj85pX.js";import"./check-ByT7pZYG.js";import"./chevron-up-Df25x0BV.js";import"./chevron-right-CNLFaFxZ.js";import"./chevron-left-cS_ZEw90.js";import"./index--W9ygoIB.js";function Pe({expenses:x,dateRangeLabel:u,open:b,onClose:v}){const[g,F]=n.useState({name:"MUGHAL ATTA CHAKKI",address:"",phone:"",tagline:""});n.useEffect(()=>{b&&fetch(`${L}/get_store_settings.php`).then(s=>s.json()).then(s=>{s.success&&s.settings&&F({name:s.settings.storeName||"MUGHAL ATTA CHAKKI",address:s.settings.address||"",phone:s.settings.phone||"",tagline:s.settings.tagline||""})}).catch(s=>console.error("Failed to load store settings",s))},[b]);const w=x.reduce((s,i)=>s+i.amount,0),p=x.reduce((s,i)=>(s[i.category]=(s[i.category]||0)+i.amount,s),{}),P=()=>{const s=window.open("","_blank","width=800,height=900");if(!s){alert("Please allow popups to print the report.");return}s.document.open(),s.document.write(N()),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},500)},N=()=>{const s=`
      <div style="display:flex;align-items:center;justify-content:center;gap:14px;padding:5px 0 10px;">
        <svg width="56" height="56" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="32" cy="32" r="32" fill="#78350f"/>
          <ellipse cx="32" cy="38" rx="16" ry="8" fill="#fef3c7" opacity="0.9"/>
          <ellipse cx="32" cy="36" rx="12" ry="6" fill="#f59e0b" opacity="0.8"/>
          <line x1="32" y1="44" x2="32" y2="18" stroke="#fef3c7" stroke-width="2" stroke-linecap="round"/>
          <ellipse cx="27" cy="28" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(-30 27 28)"/>
          <ellipse cx="26" cy="23" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(-25 26 23)"/>
          <ellipse cx="37" cy="28" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(30 37 28)"/>
          <ellipse cx="38" cy="23" rx="4" ry="2.5" fill="#fef3c7" transform="rotate(25 38 23)"/>
          <ellipse cx="32" cy="20" rx="3" ry="4" fill="#fef3c7"/>
        </svg>
        <div>
          <div style="font-size:18px;font-weight:900;letter-spacing:2px;color:#1a1a1a;text-transform:uppercase;">${g.name}</div>
          <div style="font-size:10px;color:#666;letter-spacing:1px;margin-top:2px;">${g.tagline}</div>
          <div style="font-size:10px;color:#666;margin-top:1px;">📍 ${g.address} &nbsp;|&nbsp; 📞 ${g.phone}</div>
        </div>
      </div>
    `,i=x.length===0?'<tr><td colspan="5" style="text-align:center;padding:12px;color:#666;">No expenses found for this period.</td></tr>':x.map(c=>`
          <tr>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;">${new Date(c.created_at).toLocaleDateString()}</td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;font-weight:600;">${c.category}</td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;">${c.description||"-"}</td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;">${c.user_name||"-"}</td>
            <td style="padding:8px 10px;border-bottom:1px solid #eee;text-align:right;font-weight:bold;color:#b91c1c;">Rs. ${Number(c.amount).toLocaleString()}</td>
          </tr>
        `).join(""),E=Object.entries(p).map(([c,k])=>`
      <div style="display:flex;justify-content:space-between;margin-bottom:6px;border-bottom:1px dashed #e5e7eb;padding-bottom:4px;">
        <span style="color:#4b5563;">${c}</span>
        <span style="font-weight:600;">Rs. ${Number(k).toLocaleString()}</span>
      </div>
    `).join("");return`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Expense Report - ${u}</title>
        <style>
          body { font-family: 'Inter', system-ui, -apple-system, sans-serif; padding: 20px; color: #111827; line-height: 1.5; }
          .header-section { text-align: center; border-bottom: 2px solid #78350f; padding-bottom: 15px; margin-bottom: 24px; }
          .title-area { margin-top: 15px; display:flex; justify-content: space-between; align-items:flex-end; }
          .report-title { font-size: 24px; font-weight: 800; color: #111827; margin: 0; text-transform: uppercase; }
          .report-meta { font-size: 13px; color: #4b5563; text-align:right; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 30px; font-size: 13px; }
          th { background: #f9fafb; padding: 10px; text-align: left; font-weight: 700; color: #374151; border-bottom: 2px solid #e5e7eb; }
          .summary-container { display: flex; gap: 40px; margin-top: 30px; page-break-inside: avoid; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; background: #fffaf0; }
          .summary-col { flex: 1; }
          .total-box { background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 15px; text-align: center; }
          .signatures { display: flex; justify-content: space-between; margin-top: 60px; padding-top: 20px; border-top: 1px solid #d1d5db; page-break-inside: avoid; }
          .sig-line { width: 200px; text-align: center; }
          .sig-line div { border-top: 1px solid #374151; padding-top: 5px; font-size: 13px; font-weight: 500; }
          @media print {
            body { padding: 0; }
            .no-print { display: none !important; }
            @page { margin: 15mm; }
          }
        </style>
      </head>
      <body>
        <div class="header-section">
          ${s}
          <div class="title-area">
            <div style="text-align:left;">
              <h1 class="report-title">Expense Report</h1>
              <p style="margin:4px 0 0;font-weight:500;color:#6b7280;font-size:14px;">Period: ${u}</p>
            </div>
            <div class="report-meta">
              <div>Total Entries: ${x.length}</div>
              <div>Generated: ${new Date().toLocaleString()}</div>
            </div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width:20%">Date</th>
              <th style="width:25%">Category</th>
              <th style="width:30%">Description</th>
              <th style="width:10%">Recorded By</th>
              <th style="width:15%;text-align:right;">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${i}
          </tbody>
        </table>

        <div class="summary-container">
          <div class="summary-col">
            <h3 style="margin-top:0;margin-bottom:12px;font-size:16px;color:#1f2937;border-bottom:2px solid #e5e7eb;padding-bottom:6px;">Category Breakdown</h3>
            ${E}
          </div>
          <div class="summary-col" style="display:flex;flex-direction:column;justify-content:center;">
            <div class="total-box">
              <div style="font-size:14px;font-weight:600;color:#991b1b;margin-bottom:4px;text-transform:uppercase;letter-spacing:1px;">Total Expenditure</div>
              <div style="font-size:32px;font-weight:800;color:#dc2626;">Rs. ${Number(w).toLocaleString()}</div>
            </div>
          </div>
        </div>

        <div class="signatures">
          <div class="sig-line">
            <div style="margin-top:50px;">Accountant Signature</div>
          </div>
          <div class="sig-line">
            <div style="margin-top:50px;">Owner Signature</div>
          </div>
        </div>
      </body>
      </html>
    `};return e.jsx(we,{open:b,onOpenChange:v,children:e.jsxs(Ne,{className:"max-w-[400px] text-center",children:[e.jsxs(Se,{children:[e.jsx("div",{className:"mx-auto bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4",children:e.jsx(B,{className:"h-8 w-8 text-primary"})}),e.jsx(Ce,{className:"text-xl",children:"Print Expense Report"})]}),e.jsxs("div",{className:"py-4",children:[e.jsxs("p",{className:"text-muted-foreground mb-4",children:["You are about to generate a professional expense report for ",e.jsx("br",{}),e.jsx("strong",{className:"text-foreground",children:u}),"."]}),e.jsxs("div",{className:"bg-muted/50 p-4 rounded-lg flex justify-between items-center text-sm border border-border",children:[e.jsx("span",{children:"Total Entries:"}),e.jsx("span",{className:"font-bold",children:x.length})]}),e.jsxs("div",{className:"bg-red-50 p-4 rounded-lg flex justify-between items-center text-sm border border-red-100 mt-2",children:[e.jsx("span",{className:"text-red-700",children:"Total Expenditure:"}),e.jsxs("span",{className:"font-bold text-red-700 text-lg",children:["Rs. ",w.toLocaleString()]})]})]}),e.jsxs(De,{className:"flex-col sm:flex-row gap-2 w-full mt-2",children:[e.jsxs(m,{variant:"outline",onClick:v,className:"w-full sm:flex-1",children:[e.jsx(he,{className:"h-4 w-4 mr-2"})," Cancel"]}),e.jsxs(m,{onClick:P,className:"w-full sm:flex-1 bg-primary",children:[e.jsx(B,{className:"h-4 w-4 mr-2"})," Print Document"]})]})]})})}function Ze(){const{user:x}=fe(),[u,b]=n.useState([]),[v,g]=n.useState({today:0,month:0}),[F,w]=n.useState(!0),[p,P]=n.useState(!1),[N,s]=n.useState(""),[i,E]=n.useState(""),[c,k]=n.useState(""),[oe,ne]=n.useState([]),[I,K]=n.useState(""),[y,U]=n.useState(new Date),[A,G]=n.useState(!1),[r,S]=n.useState({from:_(new Date),to:H(new Date)}),[ie,V]=n.useState(!1),O=async()=>{try{w(!0);const a=await(await fetch(`${L}/get_expenses.php`)).json();if(a.success){g(a.totals);const o=a.records.map(d=>({id:d.id,date:d.expense_time,category:d.category||"Uncategorized",amount:parseFloat(d.amount),description:d.description,recordedBy:d.recorded_by||"Admin"}));b(o)}else l.error("Failed to load expenses")}catch(t){console.error("Network Error:",t),l.error("Network Error: Could not connect to database")}finally{w(!1)}},le=async()=>{try{const a=await(await fetch(`${L}/get_products.php`)).json();a.success&&a.products&&ne(a.products.map(o=>o.name))}catch(t){console.error("Failed to load product categories",t)}};n.useEffect(()=>{O(),le()},[]);const de=async()=>{if(!N||!i||i==="Other"&&!c){l.error("Please enter amount and category details");return}const t=parseFloat(N);if(isNaN(t)||t<=0){l.error("Please enter a valid positive amount");return}P(!0);try{let a=y;const o=new Date;y.toDateString()===o.toDateString()?a=o:a.setHours(o.getHours(),o.getMinutes(),o.getSeconds());const d=a.getTimezoneOffset()*6e4,$=new Date(a-d).toISOString().slice(0,19).replace("T"," "),xe=i==="Other"?c.trim():i,pe={user_id:(x==null?void 0:x.id)||1,category:xe,amount:t,description:I,expense_time:$},Y=await(await fetch(`${L}/add_expense.php`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(pe)})).json();Y.success?(l.success("Expense recorded successfully"),s(""),E(""),k(""),K(""),U(new Date),G(!1),O()):l.error(Y.message||"Failed to record expense")}catch{l.error("Network Error while saving")}finally{P(!1)}},ce=async t=>{const a=async()=>{try{(await(await fetch(`${L}/delete_expense.php`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:t})})).json()).success?(l.success("Entry deleted"),O()):l.error("Failed to delete")}catch{l.error("Network error while deleting")}};l.custom(o=>e.jsxs("div",{className:"bg-primary border border-primary-foreground/20 rounded-lg p-4 shadow-xl flex flex-col gap-3 max-w-sm",children:[e.jsx("p",{className:"text-primary-foreground font-medium",children:"Are you sure you want to delete this entry?"}),e.jsxs("div",{className:"flex gap-2 justify-end",children:[e.jsx(m,{onClick:()=>l.dismiss(o),variant:"outline",size:"sm",className:"bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20 border-transparent",children:"Cancel"}),e.jsx(m,{onClick:()=>{l.dismiss(o),a()},size:"sm",className:"bg-destructive text-destructive-foreground hover:bg-destructive/90 border-transparent",children:"Delete"})]})]}))},C=u.filter(t=>{if(!r||!r.from)return!0;const a=typeof t.date=="string"?t.date.replace(" ","T"):t.date,o=new Date(a),d=new Date(r.from);if(d.setHours(0,0,0,0),o<d)return!1;const $=r.to?new Date(r.to):new Date(r.from);return $.setHours(23,59,59,999),!(o>$)}),me=()=>r!=null&&r.from?r.to?`${f(r.from,"dd MMM yyyy")} - ${f(r.to,"dd MMM yyyy")}`:f(r.from,"dd MMM yyyy"):"All Time";return F&&u.length===0?e.jsxs("div",{className:"flex flex-col items-center justify-center h-64 space-y-4",children:[e.jsx(J,{className:"h-8 w-8 animate-spin text-primary"}),e.jsx("p",{className:"text-muted-foreground",children:"Loading Khata Records..."})]}):e.jsxs("div",{className:"space-y-6 max-w-6xl mx-auto",children:[e.jsxs("div",{className:"flex flex-col md:flex-row md:items-center justify-between gap-4",children:[e.jsxs("div",{children:[e.jsx("h1",{className:"text-foreground mb-2",children:"Digital Khata"}),e.jsx("p",{className:"text-muted-foreground",children:"Track daily expenditures and purchases"})]}),e.jsxs("div",{className:"flex gap-2",children:[e.jsxs(m,{variant:"outline",onClick:()=>V(!0),children:[e.jsx(B,{className:"h-4 w-4 mr-2"}),"Print Report"]}),e.jsx(m,{onClick:()=>G(!A),variant:A?"outline":"default",children:A?"Cancel":e.jsxs(e.Fragment,{children:[e.jsx(ue,{className:"h-4 w-4 mr-2"})," Add New Expense"]})})]})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[e.jsx(M,{className:"p-6 bg-orange-50 border-orange-200",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-orange-800 font-medium",children:"Today's Expenditure"}),e.jsxs("h2",{className:"text-3xl font-bold text-orange-900 mt-2",children:["Rs. ",parseFloat(v.today).toLocaleString()]})]}),e.jsx("div",{className:"h-12 w-12 bg-orange-200 rounded-full flex items-center justify-center",children:e.jsx(ge,{className:"h-6 w-6 text-orange-700"})})]})}),e.jsx(M,{className:"p-6 bg-blue-50 border-blue-200",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-blue-800 font-medium",children:"This Month's Total"}),e.jsxs("h2",{className:"text-3xl font-bold text-blue-900 mt-2",children:["Rs. ",parseFloat(v.month).toLocaleString()]})]}),e.jsx("div",{className:"h-12 w-12 bg-blue-200 rounded-full flex items-center justify-center",children:e.jsx(R,{className:"h-6 w-6 text-blue-700"})})]})})]}),A&&e.jsxs(M,{className:"p-6 border-primary/20 shadow-md",children:[e.jsxs("h3",{className:"text-lg font-semibold mb-4 flex items-center gap-2",children:[e.jsx(Te,{className:"h-5 w-5 text-red-500"}),"Record New Expense"]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{children:[e.jsx(D,{htmlFor:"category",children:"Category (from Products)"}),e.jsxs(X,{value:i,onValueChange:E,children:[e.jsx(q,{disabled:p,children:e.jsx(Z,{placeholder:"Select expense type"})}),e.jsxs(ee,{children:[oe.map((t,a)=>e.jsx(T,{value:t,children:t},`cat-${a}`)),e.jsx(T,{value:"Other",children:"Other (Custom)"})]})]})]}),i==="Other"&&e.jsxs("div",{className:"animate-in fade-in slide-in-from-top-1",children:[e.jsx(D,{htmlFor:"customCategory",children:"Custom Expense Name"}),e.jsx(Q,{id:"customCategory",type:"text",className:"mt-1",placeholder:"e.g. Utility Bills, Maintenance...",value:c,onChange:t=>k(t.target.value),disabled:p})]})]}),e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{children:[e.jsx(D,{htmlFor:"amount",children:"Amount (Rs)"}),e.jsx(Q,{id:"amount",type:"number",className:"mt-1",placeholder:"0.00",value:N,onChange:t=>s(t.target.value),disabled:p})]}),e.jsxs("div",{children:[e.jsx(D,{children:"Expense Date"}),e.jsxs(te,{children:[e.jsx(se,{asChild:!0,children:e.jsxs(m,{variant:"outline",className:W("w-full justify-start text-left font-normal mt-1",!y&&"text-muted-foreground"),disabled:p,children:[e.jsx(R,{className:"mr-2 h-4 w-4"}),y?f(y,"PPP"):e.jsx("span",{children:"Pick a date"})]})}),e.jsx(re,{className:"w-auto p-0",align:"start",children:e.jsx(ae,{mode:"single",selected:y,onSelect:t=>{t&&U(t)},disabled:t=>t>new Date,initialFocus:!0})})]})]})]}),e.jsxs("div",{className:"md:col-span-2",children:[e.jsx(D,{htmlFor:"description",children:"Description / Note (Optional)"}),e.jsx(ve,{id:"description",placeholder:"Additional details...",value:I,onChange:t=>K(t.target.value),rows:2,disabled:p})]})]}),e.jsx("div",{className:"mt-4 flex justify-end",children:e.jsxs(m,{onClick:de,size:"lg",className:"w-full md:w-auto",disabled:p,children:[p?e.jsx(J,{className:"h-4 w-4 mr-2 animate-spin"}):null,p?"Saving...":"Save Record"]})})]}),e.jsxs(M,{className:"overflow-hidden",children:[e.jsxs("div",{className:"p-4 border-b bg-muted/30 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4",children:[e.jsx("h3",{className:"font-semibold",children:"Expense Records"}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs(X,{onValueChange:t=>{const a=new Date;if(t==="current")S({from:_(a),to:H(a)});else if(t==="last"){const o=new Date(a.getFullYear(),a.getMonth()-1,1);S({from:_(o),to:H(o)})}else t==="all"&&S(void 0)},children:[e.jsx(q,{className:"w-[140px] h-9",children:e.jsx(Z,{placeholder:"Quick Filter"})}),e.jsxs(ee,{children:[e.jsx(T,{value:"current",children:"This Month"}),e.jsx(T,{value:"last",children:"Last Month"}),e.jsx(T,{value:"all",children:"All Time"})]})]}),e.jsxs(te,{children:[e.jsx(se,{asChild:!0,children:e.jsxs(m,{id:"date",variant:"outline",size:"sm",className:W("w-[240px] justify-start text-left font-normal",!r&&"text-muted-foreground"),children:[e.jsx(R,{className:"mr-2 h-4 w-4"}),r!=null&&r.from?r.to?e.jsxs(e.Fragment,{children:[f(r.from,"LLL dd, y")," -"," ",f(r.to,"LLL dd, y")]}):f(r.from,"LLL dd, y"):e.jsx("span",{children:"Pick a date range"})]})}),e.jsx(re,{className:"w-auto p-0",align:"end",children:e.jsx(ae,{initialFocus:!0,mode:"range",defaultMonth:r==null?void 0:r.from,selected:r,onSelect:S,numberOfMonths:1})})]}),r&&e.jsx(m,{variant:"ghost",size:"sm",onClick:()=>S(void 0),children:"Clear"})]})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs(ye,{children:[e.jsx(je,{children:e.jsxs(z,{children:[e.jsx(j,{children:"Date"}),e.jsx(j,{children:"Category"}),e.jsx(j,{children:"Description"}),e.jsx(j,{children:"Recorded By"}),e.jsx(j,{className:"text-right",children:"Amount"}),e.jsx(j,{className:"w-[50px]"})]})}),e.jsx(be,{children:C.length===0?e.jsx(z,{children:e.jsx(h,{colSpan:6,className:"text-center py-8 text-muted-foreground",children:"No expenses found for the selected period."})}):C.map(t=>e.jsxs(z,{children:[e.jsxs(h,{className:"font-medium",children:[new Date(t.date).toLocaleDateString()," ",e.jsx("br",{}),e.jsx("span",{className:"text-xs text-muted-foreground",children:new Date(t.date).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})})]}),e.jsx(h,{children:e.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary text-secondary-foreground",children:t.category})}),e.jsx(h,{className:"max-w-xs truncate text-muted-foreground",children:t.description||"-"}),e.jsx(h,{className:"text-sm",children:t.recordedBy}),e.jsxs(h,{className:"text-right font-bold text-red-600",children:["Rs. ",t.amount.toLocaleString()]}),e.jsx(h,{children:e.jsx(m,{variant:"destructive",size:"icon",className:"h-8 w-8 px-0 flex items-center justify-center",onClick:()=>ce(t.id),children:e.jsx(Le,{className:"h-4 w-4 text-white"})})})]},t.id))})]})}),C.length>0&&e.jsxs("div",{className:"p-4 border-t bg-muted/10 flex justify-end items-center gap-4",children:[e.jsx("span",{className:"text-muted-foreground font-medium",children:"Total for period:"}),e.jsxs("span",{className:"text-xl font-bold text-foreground",children:["Rs. ",C.reduce((t,a)=>t+a.amount,0).toLocaleString()]})]})]}),e.jsx(Pe,{expenses:C,dateRangeLabel:me(),open:ie,onClose:()=>V(!1)})]})}export{Ze as DigitalKhata};
